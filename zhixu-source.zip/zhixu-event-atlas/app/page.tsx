"use client";

import { useEffect, useId, useRef, useState, type ChangeEvent, type FormEvent } from "react";
import { ArrowDown, ArrowRight, Bell, BookOpen, Check, CheckCheck, ChevronDown, ChevronRight, CircleAlert, Clock3, ExternalLink, FileCheck2, FilePlus2, FileText, GitBranch, History, Info, Layers3, LoaderCircle, Menu, Plus, RefreshCw, Search, Settings2, ShieldCheck, Sparkles, Upload, X } from "lucide-react";
import { demoState } from "../lib/fixtures";
import type { Claim, EventRecord, EventStatus, Material, MaterialInput, Relation, SourceKind, Version, WorkspaceResponse, WorkspaceState } from "../lib/types";

const statusLabels: Record<EventStatus, string> = { planning: "筹划中", progress: "推进中", completed: "已完成", terminated: "已终止", denied: "已否认", uncertain: "待核实", expired: "时效已更新" };
const relationLabels: Record<Relation, string> = { initial: "首次披露", supports: "支持原结论", supplements: "补充证据", contradicts: "证据冲突", corrects: "更正披露", denies: "否认原陈述", progresses: "状态推进" };
const sourceLabels: Record<SourceKind, string> = { official: "官方公告", media: "媒体报道", research: "研究资料", other: "其他来源" };
const kindLabels = { fact: "事实", opinion: "观点", inference: "推测", rumor: "传闻" };
const emptyState: WorkspaceState = { schemaVersion: 1, materials: [], events: [], notifications: [], runs: [], usage: { day: "", count: 0 }, activeRun: null };
const emptyForm: MaterialInput = { title: "", text: "", sourceUrl: "", sourceKind: "official", publishedAt: null };
const tabs = ["时间线", "证据", "版本", "调用记录"] as const;
type Tab = typeof tabs[number];
type Modal = "import" | "settings" | "about" | null;

function dateLabel(value: string | null | undefined, full = false) {
  if (!value) return "未知";
  if (/^\d{4}-\d{2}-\d{2}$/.test(value)) return value.replaceAll("-", ".");
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat("zh-CN", { timeZone: "Asia/Shanghai", year: "numeric", month: "2-digit", day: "2-digit", ...(full ? { hour: "2-digit", minute: "2-digit", hour12: false } : {}) }).format(date).replaceAll("/", ".");
}
function shanghaiDay() { const parts = new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Shanghai", year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(new Date()); return ["year", "month", "day"].map(kind => parts.find(part => part.type === kind)?.value).join("-"); }
function safeUrl(value: string) { try { const url = new URL(value); return ["http:", "https:"].includes(url.protocol) ? url.href : undefined; } catch { return undefined; } }
function sourceHost(value: string) { try { return new URL(value).hostname.replace(/^www\./, ""); } catch { return "原始材料"; } }
function Status({ status }: { status: EventStatus }) { return <span className={`status status-${status}`}><i />{statusLabels[status]}</span>; }
function Hint({ label, children }: { label: string; children: string }) {
  const id = useId();
  const [hovered, setHovered] = useState(false);
  const [focused, setFocused] = useState(false);
  const [pinned, setPinned] = useState(false);
  const [dismissed, setDismissed] = useState(false);
  const visible = !dismissed && (hovered || focused || pinned);
  return <span className={`hint ${visible ? "hint-open" : ""}`} onMouseEnter={() => { setHovered(true); setDismissed(false); }} onMouseLeave={() => setHovered(false)} onBlur={event => { if (!event.currentTarget.contains(event.relatedTarget)) { setFocused(false); setPinned(false); setDismissed(false); } }}>
    <button type="button" className="hint-button" aria-label={label} aria-describedby={visible ? id : undefined} aria-expanded={visible} onFocus={() => { setFocused(true); setDismissed(false); }} onClick={() => { setPinned(!pinned); setDismissed(pinned); }} onKeyDown={event => { if (event.key === "Escape") { setPinned(false); setDismissed(true); } }}><Info size={15} /></button>
    <span id={id} role="tooltip" className="hint-content">{children}</span>
  </span>;
}
function Provenance({ version }: { version?: Version }) { return <span className="provenance">{version?.provenance === "deepseek" ? <Sparkles size={12} /> : <ShieldCheck size={12} />}{version?.provenance === "deepseek" ? "AI 分析 · 文本引用已校验" : version?.provenance === "expiry" ? "规则检查 · 时效更新" : "人工核验"}</span>; }

export default function Home() {
  const [mode, setMode] = useState<"history" | "research">("research");
  const [workspace, setWorkspace] = useState<WorkspaceState>(emptyState);
  const [config, setConfig] = useState({ configured: false, authenticated: false, model: "DeepSeek", identityKind: "guest" as "guest" | "account", dailyLimit: 10, globalDailyLimit: 50 });
  const [loaded, setLoaded] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [toast, setToast] = useState("");
  const [busy, setBusy] = useState<string | null>(null);
  const [eventId, setEventId] = useState<string | null>(null);
  const [versionNumber, setVersionNumber] = useState<number | null>(null);
  const [materialId, setMaterialId] = useState<string | null>(null);
  const [tab, setTab] = useState<Tab>("时间线");
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [modal, setModal] = useState<Modal>(null);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [evidenceOpen, setEvidenceOpen] = useState(false);
  const [form, setForm] = useState<MaterialInput>(emptyForm);
  const [formError, setFormError] = useState("");
  const [analyzeAfterImport, setAnalyzeAfterImport] = useState(true);
  const [mobileNav, setMobileNav] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const modalRef = useRef<HTMLDivElement>(null);
  const evidenceRef = useRef<HTMLElement>(null);
  const sidebarRef = useRef<HTMLElement>(null);
  const state = mode === "history" ? demoState : workspace;
  function filterEvents(events: EventRecord[]) {
    return events.filter(item => (statusFilter === "all" || item.status === statusFilter) && `${item.title} ${item.companies.map(company => `${company.name} ${company.code}`).join(" ")}`.toLowerCase().includes(query.toLowerCase())).sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
  }
  const personalEvents = filterEvents(workspace.events);
  const sampleEvents = filterEvents(demoState.events);
  const event = state.events.find(item => item.id === eventId);
  const versions = event?.versions ?? [];
  const latestVersion = versions[versions.length - 1];
  const version = versions.find(item => item.number === versionNumber) ?? latestVersion;
  const isHistoricalVersion = !!version && !!latestVersion && version.id !== latestVersion.id;
  const visibleVersions = versions.filter(item => !version || item.number <= version.number);
  const visibleMaterialIds = new Set(visibleVersions.map(item => item.materialId));
  const materials = state.materials.filter(item => event?.materialIds.includes(item.id) && (!isHistoricalVersion || visibleMaterialIds.has(item.id)));
  const material = state.materials.find(item => item.id === materialId) ?? state.materials.find(item => item.id === version?.materialId) ?? materials[0];
  const claims = version?.claims ?? [];
  const materialClaims = [...new Map(visibleVersions.flatMap(item => item.claims).filter(claim => claim.materialId === material?.id).map(claim => [claim.id, claim])).values()];
  const pending = workspace.materials.filter(item => ["pending", "failed", "review"].includes(item.status));
  const unread = workspace.notifications.filter(item => !item.read).length;
  const usedToday = workspace.usage.day === shanghaiDay() ? workspace.usage.count : 0;
  const remainingAnalyses = Math.max(0, config.dailyLimit - usedToday);
  const canAnalyze = config.authenticated && config.configured && remainingAnalyses > 0;
  const isGuest = config.identityKind === "guest";
  const spaceStatus = config.authenticated ? (isGuest ? "游客空间已连接" : "研究空间已连接") : loading || (!loaded && !error) ? "研究空间连接中" : "研究空间连接失败，请刷新";
  const shownStatus = version?.status ?? event?.status;
  const evidenceCount = new Set(claims.map(claim => claim.materialId)).size;

  async function loadWorkspace(preserveError = false) {
    setLoading(true); if (!preserveError) setError("");
    try {
      const response = await fetch("/api/workspace", { cache: "no-store" });
      const data = await response.json() as WorkspaceResponse & { error?: string };
      if (!response.ok) throw new Error(data.error || "研究空间暂时无法读取");
      setWorkspace(data.state); setConfig({ configured: data.configured, authenticated: data.authenticated, model: data.model, identityKind: data.identityKind, dailyLimit: data.dailyLimit, globalDailyLimit: data.globalDailyLimit }); setLoaded(true);
    } catch (cause) { if (!preserveError) setError(cause instanceof Error ? cause.message : "连接失败，请重试"); }
    finally { setLoading(false); }
  }
  useEffect(() => { void loadWorkspace(); }, []);
  useEffect(() => { if (!toast) return; const timer = setTimeout(() => setToast(""), 4200); return () => clearTimeout(timer); }, [toast]);
  useEffect(() => {
    if (!modal && !evidenceOpen && !mobileNav && !notificationsOpen) return;
    function closeOnEscape(e: KeyboardEvent) { if (e.key === "Escape") { setModal(null); setEvidenceOpen(false); setMobileNav(false); setNotificationsOpen(false); } }
    window.addEventListener("keydown", closeOnEscape);
    return () => window.removeEventListener("keydown", closeOnEscape);
  }, [modal, evidenceOpen, mobileNav, notificationsOpen]);

  useEffect(() => {
    const surface = modal ? modalRef.current : evidenceOpen ? evidenceRef.current : mobileNav ? sidebarRef.current : null;
    if (!surface) return;
    const previousFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const selectors = [".topbar", ".research-content", ".global-error"];
    if (modal || evidenceOpen) selectors.push(".sidebar");
    if (modal) selectors.push(".evidence-panel");
    const background = [...document.querySelectorAll<HTMLElement>(selectors.join(","))].map(element => ({ element, inert: element.inert }));
    background.forEach(({ element }) => { element.inert = true; });
    surface.focus({ preventScroll: true });
    function trapFocus(event: KeyboardEvent) {
      if (event.key !== "Tab" || !surface) return;
      const controls = [...surface.querySelectorAll<HTMLElement>('button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), a[href], summary, [tabindex="0"]')].filter(element => element.offsetParent !== null);
      if (!controls.length) { event.preventDefault(); surface.focus(); return; }
      const first = controls[0], last = controls[controls.length - 1];
      if (!surface.contains(document.activeElement) || document.activeElement === surface) { event.preventDefault(); (event.shiftKey ? last : first).focus(); }
      else if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    }
    document.addEventListener("keydown", trapFocus);
    return () => {
      document.removeEventListener("keydown", trapFocus);
      background.forEach(({ element, inert }) => { element.inert = inert; });
      if (previousFocus?.isConnected) previousFocus.focus({ preventScroll: true });
    };
  }, [modal, evidenceOpen, mobileNav]);

  async function mutate(path: string, body: unknown, key: string): Promise<{ state: WorkspaceState; material?: Material } | null> {
    setBusy(key); setError("");
    try {
      const response = await fetch(`/api/${path}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
      const data = await response.json() as { state: WorkspaceState; material?: Material; error?: string };
      if (!response.ok) throw new Error(data.error || "操作失败，请稍后重试");
      setWorkspace(data.state); return data;
    } catch (cause) { setError(cause instanceof Error ? cause.message : "操作失败，请稍后重试"); return null; }
    finally { setBusy(null); }
  }
  function newResearch() {
    window.scrollTo({ top: 0, behavior: "instant" });
    setMode("research"); setEventId(null); setVersionNumber(null); setMaterialId(null); setTab("时间线"); setMobileNav(false); setEvidenceOpen(false); setModal(null); setFormError("");
  }
  function selectEvent(nextId: string, nextMode: "history" | "research" = "research") {
    window.scrollTo({ top: 0, behavior: "instant" });
    setMode(nextMode); setEventId(nextId); setVersionNumber(null); setMaterialId(null); setTab("时间线"); setMobileNav(false); setEvidenceOpen(false);
  }
  function selectVersion(next: Version) { setVersionNumber(next.number); setMaterialId(next.materialId); }
  function inspectMaterial(id: string) { setMaterialId(id); setEvidenceOpen(true); }
  function openImport() {
    if (mode === "history" || !event) { newResearch(); return; }
    setFormError(""); setModal("import");
  }
  async function analyze(id: string) {
    const result = await mutate("analyze", { materialId: id }, `analyze-${id}`);
    if (result) {
      const updated = result.state.materials.find(item => item.id === id);
      if (updated?.eventId) { window.scrollTo({ top: 0, behavior: "instant" }); setMode("research"); setEventId(updated.eventId); setVersionNumber(null); setMaterialId(id); }
      setToast(updated?.status === "review" ? "分析完成，事件归属需要你确认" : "分析已完成，结论与证据已更新");
    } else { await loadWorkspace(true); }
  }
  async function submitMaterial(e: FormEvent) {
    e.preventDefault(); setFormError("");
    if (form.title.trim().length < 2 || form.text.trim().length < 20 || !safeUrl(form.sourceUrl)) { setFormError("请填写至少 2 字标题、20 字正文和有效的 http / https 原始链接。"); return; }
    const result = await mutate("materials", form, "import");
    if (result?.material) {
      window.scrollTo({ top: 0, behavior: "instant" }); setModal(null); setMode("research"); setEventId(null); setVersionNumber(null); setTab("时间线"); setForm(emptyForm); setMaterialId(result.material.id); setToast("材料已保存，导入文本已留存供核验");
      if (analyzeAfterImport && canAnalyze && result.material.status !== "analyzed") await analyze(result.material.id);
    }
  }
  async function importFile(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]; if (!file) return;
    try {
      if (file.size > 80 * 1024) throw new Error("文件超过 80 KB，请精简为与事件有关的文本后重试。");
      if (!/\.(txt|json)$/i.test(file.name)) throw new Error("仅支持 TXT 或 JSON 文件。");
      const text = await file.text();
      if (file.name.toLowerCase().endsWith(".json")) {
        const parsed = JSON.parse(text);
        if (!parsed || typeof parsed.title !== "string" || typeof parsed.text !== "string") throw new Error("JSON 需包含 title、text 字段，可选 sourceUrl、sourceKind、publishedAt。");
        setForm({ title: parsed.title, text: parsed.text, sourceUrl: typeof parsed.sourceUrl === "string" ? parsed.sourceUrl : "", sourceKind: ["official", "media", "research", "other"].includes(parsed.sourceKind) ? parsed.sourceKind : "other", publishedAt: typeof parsed.publishedAt === "string" ? parsed.publishedAt : null });
      } else { setForm(current => ({ ...current, title: current.title || file.name.replace(/\.txt$/i, ""), text })); }
      setFormError("");
    } catch (cause) { setFormError(cause instanceof Error ? cause.message : "文件无法读取，请选择 UTF-8 文本或 JSON 文件。"); }
    finally { e.target.value = ""; }
  }
  async function resolve(id: string, target: string | null) {
    const result = await mutate("resolve", { materialId: id, eventId: target }, `resolve-${id}`);
    if (result) { window.scrollTo({ top: 0, behavior: "instant" }); const updated = result.state.materials.find(item => item.id === id); setEventId(updated?.eventId ?? null); setVersionNumber(null); setMaterialId(id); setToast(target ? "已确认归入该事件" : "已创建独立事件"); }
  }
  async function readNotice(id?: string) { const result = await mutate("notifications/read", id ? { id } : {}, "notice"); if (result && !id) setToast("提醒已全部标为已读"); }

  const visibleRuns = event ? state.runs.filter(run => event.materialIds.includes(run.materialId)) : workspace.runs;
  const runPanel = <div className="runs-panel" role="tabpanel"><div className="timeline-heading"><span>分析调用</span><span>{event ? "当前事件" : "整个研究空间 · 含未归属材料"}</span></div>{visibleRuns.length ? visibleRuns.slice().reverse().map(run => <article className="run-card" key={run.id}><div><span className={`run-status ${run.status}`}><i />{run.status === "success" ? "分析成功" : run.status === "review" ? "等待归属确认" : "分析失败"}</span><time>{dateLabel(run.createdAt, true)}</time></div><strong>{run.model}</strong><p>{state.materials.find(item => item.id === run.materialId)?.title || run.materialId}</p><button className="text-button" onClick={() => inspectMaterial(run.materialId)}>查看导入文本<ArrowRight size={13} /></button><dl><div><dt>提示词版本</dt><dd>{run.promptVersion}</dd></div><div><dt>耗时</dt><dd>{(run.durationMs / 1000).toFixed(1)} 秒</dd></div><div><dt>Token 用量</dt><dd>{run.usage?.total_tokens?.toLocaleString() ?? "未记录"}</dd></div></dl>{run.error && <p className="run-error">{run.error}</p>}</article>) : <div className="quiet-empty"><ShieldCheck size={28} /><h3>{mode === "history" ? "示例无 AI 调用记录" : "暂无 AI 调用记录"}</h3><p>{mode === "history" ? "此示例由真实公告人工整理。" : "完成一次真实分析后，将显示模型、耗时和用量。"}</p></div>}</div>;

  const composer = <form className="material-form" onSubmit={submitMaterial}><p className="form-intro">上传文件，或粘贴材料正文。</p>{!config.authenticated && <div className="space-connect-callout"><ShieldCheck size={16} /><span>{spaceStatus}。可先整理材料，连接后保存。</span><button type="button" disabled={loading} onClick={() => void loadWorkspace()}>刷新连接<RefreshCw size={13} /></button></div>}<div className="import-tools"><button className="file-upload" type="button" onClick={() => fileRef.current?.click()}><Upload size={16} /><span>上传 TXT / JSON</span><small>≤80 KB</small></button><input ref={fileRef} type="file" accept=".txt,.json,text/plain,application/json" onChange={importFile} hidden /></div><label className="field"><span>材料标题 <i>*</i></span><input required maxLength={160} placeholder="例如：关于终止重大资产重组的公告" value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} /></label><div className="form-row"><label className="field"><span>来源类型</span><select value={form.sourceKind} onChange={e => setForm({ ...form, sourceKind: e.target.value as SourceKind })}>{Object.entries(sourceLabels).map(([key, label]) => <option value={key} key={key}>{label}</option>)}</select></label><label className="field"><span>披露日期 <small>可留空</small></span><input type="date" value={form.publishedAt?.slice(0, 10) ?? ""} onChange={e => setForm({ ...form, publishedAt: e.target.value || null })} /></label></div><label className="field"><span>原始链接 <i>*</i></span><input type="url" required placeholder="https://…" value={form.sourceUrl} onChange={e => setForm({ ...form, sourceUrl: e.target.value })} /></label><label className="field"><span>材料正文 <i>*</i><small>{form.text.length.toLocaleString()} 字</small></span><textarea required rows={7} maxLength={20000} placeholder="粘贴公告、报道或研究资料原文，至少 20 字。" value={form.text} onChange={e => setForm({ ...form, text: e.target.value })} /></label><label className="checkbox-label"><input type="checkbox" checked={analyzeAfterImport} onChange={e => setAnalyzeAfterImport(e.target.checked)} disabled={!canAnalyze} /><span>保存后立即分析 <small>{canAnalyze ? `今日剩余 ${remainingAnalyses} 次 · ${config.model}` : !config.configured ? "分析服务暂不可用，当前仅保存材料" : remainingAnalyses === 0 ? "今日额度已用完，当前仅保存材料" : "研究空间连接后可用"}</small></span></label>{(formError || error) && <p className="form-error" role="alert"><CircleAlert size={15} />{formError || error}</p>}<div className="form-actions"><span>来源链接供人工核验，不自动抓取。</span>{modal === "import" && <button className="button secondary" type="button" onClick={() => setModal(null)}>取消</button>}<button className="button primary" type="submit" disabled={!!busy || !config.authenticated}>{busy === "import" ? <LoaderCircle className="spin" size={15} /> : <FilePlus2 size={15} />}{busy === "import" ? "正在保存…" : analyzeAfterImport && canAnalyze ? "保存并分析" : "保存材料"}</button></div></form>;

  function eventRows(events: EventRecord[], kind: "research" | "history") {
    return events.map(item => <button key={item.id} className={`event-index-item ${mode === kind && item.id === eventId ? "selected" : ""}`} aria-current={mode === kind && item.id === eventId ? "page" : undefined} onClick={() => selectEvent(item.id, kind)}>
      <span className="index-text"><strong>{item.title}</strong><span>{statusLabels[item.status]}<i />{dateLabel(item.updatedAt)}</span></span>
    </button>);
  }

  return <div className="workbench">
    {mobileNav && <button className="nav-scrim" aria-label="关闭导航" onClick={() => setMobileNav(false)} />}
    <aside className={`sidebar ${mobileNav ? "sidebar-open" : ""}`} aria-label="研究导航" ref={sidebarRef} tabIndex={-1} role={mobileNav ? "dialog" : undefined} aria-modal={mobileNav ? true : undefined}>
      <div className="sidebar-header">
        <button className="brand" onClick={newResearch} aria-label="知序，新建研究"><span className="brand-symbol"><Layers3 size={20} /></span><span>知序</span></button>
        <button className="icon-button mobile-close" aria-label="关闭导航" onClick={() => setMobileNav(false)}><X size={18} /></button>
      </div>
      <button className={`new-research ${mode === "research" && !event && tab !== "调用记录" ? "active" : ""}`} onClick={newResearch}><Plus size={18} />新建研究</button>
      <div className="sidebar-search"><Search size={15} /><input aria-label="搜索公司或事件" placeholder="搜索历史事件" value={query} onChange={e => setQuery(e.target.value)} />{query && <button className="icon-button" aria-label="清除搜索" onClick={() => setQuery("")}><X size={13} /></button>}</div>
      <div className="sidebar-history">
        <div className="sidebar-list-heading"><span>历史研究</span><span>{workspace.events.length}</span></div>
        <label className="sidebar-filter"><span>状态</span><select aria-label="筛选事件状态" value={statusFilter} onChange={e => setStatusFilter(e.target.value)}><option value="all">全部状态</option>{Object.entries(statusLabels).map(([key, label]) => <option value={key} key={key}>{label}</option>)}</select></label>
        <div className="event-index">{eventRows(personalEvents, "research")}{personalEvents.length === 0 && <p className="sidebar-empty">{!loaded ? "正在读取…" : workspace.events.length ? "没有匹配的事件" : "分析后的事件会保存在这里"}</p>}</div>
        <div className="sample-group"><div className="sidebar-list-heading"><span>示例案例</span><span className="readonly-label">只读</span></div><div className="event-index">{eventRows(sampleEvents, "history")}{sampleEvents.length === 0 && <p className="sidebar-empty">没有匹配的示例</p>}</div></div>
      </div>
      <div className="sidebar-bottom">
        <button className={`sidebar-settings ${!event && tab === "调用记录" ? "selected" : ""}`} onClick={() => { newResearch(); setTab("调用记录"); }}><History size={16} /><span>全部调用记录</span><span className="nav-count">{workspace.runs.length}</span></button>
        <button className="sidebar-settings" onClick={() => setModal("settings")}><Settings2 size={16} /><span>服务与额度</span><span className={`connection-dot ${config.configured && config.authenticated ? "connected" : ""}`} /></button>
        <div className="sidebar-footnote"><span>个人研究空间</span><Hint label="研究空间说明">资料保存在服务端，通过当前浏览器关联。无需登录；换浏览器或清除 Cookie 后无法找回。分析时标题和正文会发送给分析服务。</Hint><button onClick={() => setModal("about")}>关于</button></div>
      </div>
    </aside>

    <div className="workspace-main">
      <header className="topbar">
        <div className="breadcrumb"><button className="mobile-menu icon-button" aria-label="打开导航" onClick={() => setMobileNav(true)}><Menu size={20} /></button><span>事件研究台</span><ChevronRight size={14} /><strong>{event ? mode === "history" ? "只读示例" : "历史事件" : tab === "调用记录" ? "调用记录" : "新建研究"}</strong></div>
        <div className="topbar-actions">
          <button className="quota-button" onClick={() => setModal("settings")}>{loaded ? `今日剩余 ${remainingAnalyses} 次` : "连接中…"}</button>
          <div className="notification-wrap"><button className="icon-button notification-button" aria-label={`站内提醒，${unread} 条未读`} aria-expanded={notificationsOpen} onClick={() => setNotificationsOpen(!notificationsOpen)}><Bell size={19} />{unread > 0 && <i />}</button>{notificationsOpen && <div className="notifications"><div className="popover-heading"><strong>事件动态</strong><button disabled={!!busy} onClick={() => void readNotice()}><CheckCheck size={14} />全部已读</button></div>{workspace.notifications.length ? workspace.notifications.slice().reverse().map(notice => <button className={`notice ${notice.read ? "read" : ""}`} key={notice.id} onClick={() => { selectEvent(notice.eventId, "research"); void readNotice(notice.id); setNotificationsOpen(false); }}><span className="notice-dot" /><span><strong>{notice.title}</strong><p>{notice.body}</p><small>{dateLabel(notice.createdAt, true)}</small></span></button>) : <div className="popover-empty">暂无事件动态</div>}<p className="popover-foot">仅站内提醒</p></div>}</div>
          {event && <button className="button primary import-top" onClick={openImport}><Plus size={16} />{mode === "history" ? "新建研究" : "添加材料"}</button>}
        </div>
      </header>
      {error && <div className="global-error" role="alert"><CircleAlert size={17} /><span>{error}</span><button onClick={() => void loadWorkspace()}>重新连接</button><button className="icon-button" aria-label="关闭错误信息" onClick={() => setError("")}><X size={15} /></button></div>}
      <div className="content-grid">
        <main className="research-content">
          {mode === "research" && busy?.startsWith("analyze-") && <div className="analysis-progress" role="status"><LoaderCircle size={17} className="spin" /><span>正在分析材料，完成后更新事件记录。</span></div>}
          {!event && tab !== "调用记录" && <section className="composer-section" aria-labelledby="composer-title">
            <div className="page-heading"><div><h1 id="composer-title">新建研究</h1><p>添加一份材料，建立或更新事件记录。</p></div><Hint label="材料与分析说明">支持 TXT 和 JSON 文件，或直接粘贴正文。材料保存到个人空间；分析将根据内容判断事件归属，存疑时由你确认。来源类型由你标注，仍需核查原件。</Hint></div>
            {composer}
          </section>}

          {mode === "research" && pending.length > 0 && <section className="pending-section"><div className="section-title"><span><CircleAlert size={15} />待处理材料</span><small>{pending.length} 份</small></div>{pending.map(item => <div className={`pending-card ${item.status === "review" ? "review-card" : ""}`} key={item.id}><div className="pending-heading"><FileText size={17} /><strong>{item.title}</strong><span className="tiny-badge">{item.status === "review" ? "待确认归属" : item.status === "failed" ? "分析失败" : "待分析"}</span></div>{item.status === "review" && item.proposedAnalysis ? <><p>{item.proposedAnalysis.rationale}</p><div className="review-proposal"><span>建议归入</span><strong>{workspace.events.find(event => event.id === item.proposedAnalysis?.suggestedEventId)?.title || "未找到候选事件，请独立建档"}</strong></div><div className="pending-actions">{item.proposedAnalysis.suggestedEventId && <button className="button primary small" disabled={!!busy} onClick={() => void resolve(item.id, item.proposedAnalysis!.suggestedEventId)}><Check size={14} />确认归入该事件</button>}<button className="button secondary small" disabled={!!busy} onClick={() => void resolve(item.id, null)}>作为独立事件</button><button className="text-button" onClick={() => inspectMaterial(item.id)}>查看原文<ArrowRight size={13} /></button></div></> : <><p>{item.error || "材料已保存，分析完成后将建立或更新事件时间线。"}</p><div className="pending-actions"><button className="button primary small" disabled={!!busy || !canAnalyze} onClick={() => void analyze(item.id)}>{busy === `analyze-${item.id}` ? <LoaderCircle className="spin" size={14} /> : <Sparkles size={14} />}{busy === `analyze-${item.id}` ? "正在分析…" : item.status === "failed" ? "重新分析" : "开始分析"}</button>{!config.configured && <button className="text-button" onClick={() => setModal("settings")}>查看服务状态<ArrowRight size={13} /></button>}{config.configured && remainingAnalyses === 0 && <span className="quota-exhausted">今日分析额度已用完，次日恢复</span>}<button className="text-button" onClick={() => inspectMaterial(item.id)}>查看原文</button></div></>}</div>)}</section>}

          {event && <>
            <section className="event-heading"><div className="event-metadata"><span className="category-label">{event.category}</span><span className="thin-separator" /><span>{mode === "history" ? "只读示例 · 人工核验" : "个人研究事件"}</span><span className="event-reference">{event.id.slice(-8).toUpperCase()}</span></div><h2>{event.title}</h2><div className="company-row">{event.companies.map(company => <span className="company-chip" key={`${company.code}-${company.name}`}><span className="company-monogram">{company.name.slice(0, 1)}</span><strong>{company.name}</strong><span>{company.code}</span></span>)}<span className="company-note">直接参与主体</span></div></section>
            <section className="conclusion-card"><div className="conclusion-top"><span><strong>{isHistoricalVersion ? "当时结论" : "当前结论"}</strong></span>{shownStatus && <Status status={shownStatus} />}</div><p className="conclusion-summary">{version?.summary ?? event.summary}</p>{isHistoricalVersion && <div className="timeline-heading" style={{ margin: "0 0 16px" }}><span>正在回看 V{String(version.number).padStart(2, "0")} · 后续已有新结论</span><button className="text-button" onClick={() => { setVersionNumber(null); setMaterialId(latestVersion.materialId); }}>返回最新结论<ArrowRight size={13} /></button></div>}<div className="conclusion-bottom"><Provenance version={version} /><span><Clock3 size={12} />{version?.asOf ? "截至" : "结论更新"} {dateLabel(version?.asOf ?? version?.updatedAt ?? event.updatedAt)}</span><button onClick={() => setTab("证据")}>{evidenceCount || materials.length} 份依据<ArrowRight size={13} /></button></div>{version?.reason && <div className="change-note"><GitBranch size={14} /><span><strong>{version.relation === "initial" ? "建档依据" : "本次变化"}</strong>{version.reason}</span></div>}</section>
            {mode === "history" && versions.length > 1 && <section className="replay-strip" aria-label="历史阶段回放"><div className="replay-label"><History size={14} /><span>回到当时</span></div><div className="replay-steps">{versions.map((item, index) => <button key={item.id} className={`${version?.id === item.id ? "active" : ""} ${item.number < (version?.number ?? 0) ? "passed" : ""}`} onClick={() => selectVersion(item)}><span className="step-node">{item.number < (version?.number ?? 0) ? <Check size={10} /> : index + 1}</span><span><strong>{statusLabels[item.status]}</strong><small>{dateLabel(item.asOf ?? item.updatedAt)}</small></span></button>)}</div></section>}
            <div className="detail-tabs"><div role="tablist" aria-label="事件详情">{tabs.map(label => <button key={label} role="tab" aria-selected={tab === label} className={tab === label ? "active" : ""} onClick={() => setTab(label)}>{label}{label === "时间线" && <span>{visibleVersions.length.toString().padStart(2, "0")}</span>}{label === "证据" && <span>{materials.length.toString().padStart(2, "0")}</span>}</button>)}</div>{mode === "research" && <button className="refresh-button" disabled={!!busy} onClick={async () => { const result = await mutate("expire", {}, "expire"); if (result) setToast("明确有效期已检查，历史事实继续保留"); }}><RefreshCw size={13} className={busy === "expire" ? "spin" : ""} />检查时效</button>}</div>
            {tab === "时间线" && <div className="timeline-panel" role="tabpanel"><div className="timeline-heading"><span>结论时间线</span><span><ArrowDown size={12} />按结论版本倒序</span></div><div className="timeline">{visibleVersions.slice().reverse().map((item, index) => { const source = state.materials.find(material => material.id === item.materialId); return <article className={`timeline-item ${index === 0 ? "latest" : ""}`} key={item.id}><div className="timeline-marker"><span>{index === 0 ? <GitBranch size={14} /> : <span />}</span><time>{dateLabel(source?.publishedAt ?? item.asOf ?? item.updatedAt)}</time><small>{source?.publishedAt ? "披露日期" : item.asOf ? "结论截至日" : "结论更新日"}</small></div><div className="timeline-card"><div className="timeline-card-top"><span className={`relation-label relation-${item.relation}`}>{relationLabels[item.relation]}</span><span className="version-tag">V{String(item.number).padStart(2, "0")}</span>{index === 0 && <span className="latest-label">{item.id === latestVersion?.id ? "最新版本" : "回放节点"}</span>}</div><h3>{source?.title ?? statusLabels[item.status]}</h3><p>{item.summary}</p>{item.claims[0] && <button className="quote-preview" onClick={() => inspectMaterial(item.claims[0].materialId)}><span>“</span><span>{item.claims[0].quote}</span><ArrowRight size={14} /></button>}<div className="timeline-card-bottom"><span><ShieldCheck size={12} />{source ? `${source.origin === "user" ? "用户标注 · " : ""}${sourceLabels[source.sourceKind]}` : "保留的历史证据"}</span><span>披露 {dateLabel(source?.publishedAt)}</span><button onClick={() => inspectMaterial(item.materialId)}>查看证据<ArrowRight size={13} /></button></div></div></article>; })}</div><div className="timeline-end"><span />首次记录</div></div>}
            {tab === "证据" && <div className="evidence-list-panel" role="tabpanel"><div className="timeline-heading"><span>材料与证据</span><span>{materials.length} 份材料</span></div>{materials.map((item, index) => <button className={`evidence-list-card ${material?.id === item.id ? "selected" : ""}`} key={item.id} onClick={() => inspectMaterial(item.id)}><span className="evidence-file-icon"><FileText size={21} /></span><span className="evidence-list-copy"><small>{item.origin === "historical" ? sourceLabels[item.sourceKind] : `用户标注 · ${sourceLabels[item.sourceKind]}`}<i />{dateLabel(item.publishedAt)}</small><strong>{item.title}</strong><span>{sourceHost(item.sourceUrl)}{item.pageHint ? ` · ${item.pageHint}` : " · 导入文本留存"}</span></span><span className="evidence-list-number">{String(index + 1).padStart(2, "0")}</span><ChevronRight size={16} /></button>)}<div className="source-explanation"><span>来源权重说明</span><Hint label="来源权重说明">权重依据来源身份、原文直接程度与独立证据。官方预案表达拟议安排，不表示交易一定完成；来源权威性不等于实现概率。</Hint></div></div>}
            {tab === "版本" && <div className="versions-panel" role="tabpanel"><div className="timeline-heading"><span>历史版本</span><span>不可变版本快照</span></div>{versions.slice().reverse().map(item => <article className="version-card" key={item.id}><div className="version-card-heading"><span className="version-large">V{String(item.number).padStart(2, "0")}</span><Status status={item.status} /><span>{dateLabel(item.updatedAt, true)}</span></div><p>{item.summary}</p><div className="version-reason"><GitBranch size={13} />{relationLabels[item.relation]} · {item.reason}</div><div className="version-card-foot"><Provenance version={item} /><button onClick={() => { selectVersion(item); setTab("时间线"); }}>回看此版本<ArrowRight size={13} /></button></div></article>)}</div>}
            {tab === "调用记录" && runPanel}
          </>}
          {mode === "research" && !event && tab === "调用记录" && <><div className="detail-tabs"><div role="tablist" aria-label="研究空间记录"><button role="tab" aria-selected={tab === "调用记录"} className={tab === "调用记录" ? "active" : ""} onClick={() => setTab("调用记录")}>调用记录<span>{visibleRuns.length.toString().padStart(2, "0")}</span></button></div><span className="calls-scope">整个研究空间</span></div>{tab === "调用记录" && runPanel}</>}
          <footer className="content-footer">仅辅助事实研究 · 信息以原始披露为准</footer>
        </main>

        <aside className={`evidence-panel ${evidenceOpen ? "evidence-open" : ""}`} aria-label="导入材料与来源面板" aria-hidden={!evidenceOpen} ref={evidenceRef} tabIndex={-1} role="dialog" aria-modal={evidenceOpen ? true : undefined}><div className="evidence-panel-heading"><span><FileCheck2 size={17} /><strong>证据核验</strong></span><button className="icon-button close-evidence" aria-label="关闭证据面板" onClick={() => setEvidenceOpen(false)}><X size={18} /></button><span className="evidence-live">导入文本留存</span></div>{material ? <><div className="evidence-document-heading"><div><span className="document-file"><FileText size={21} /></span><span className="source-badge">{material.origin === "historical" ? sourceLabels[material.sourceKind] : `用户标注 · ${sourceLabels[material.sourceKind]}`}</span></div><h3>{material.title}</h3><span className="document-origin">{material.origin === "historical" ? "人工核验摘要 · 附原件短引" : "用户导入文本 · 来源身份待核验"}</span></div><div className="document-date-grid"><div><span>发生时间</span><strong>{dateLabel(material.occurredAt)}</strong></div><div><span>披露时间</span><strong>{dateLabel(material.publishedAt)}</strong></div><div><span>抓取时间</span><strong>{material.fetchedAt ? dateLabel(material.fetchedAt, true) : "未自动抓取"}</strong></div><div><span>导入时间</span><strong>{dateLabel(material.ingestedAt, true)}</strong></div></div><div className="evidence-section-label"><span>关键证据摘录</span><small>{materialClaims.length || "导入文本"}</small></div><div className="claim-list">{materialClaims.length ? materialClaims.map((claim: Claim) => <article className="claim-card" key={claim.id}><span className={`claim-kind kind-${claim.kind}`}>{kindLabels[claim.kind]}</span>{claim.expired && <span className="expired-claim">已过有效期</span>}<p>“{claim.quote}”</p><span className="claim-description">{claim.text}</span>{claim.validUntil && <small>明确有效期至 {dateLabel(claim.validUntil)}</small>}</article>) : <div className="raw-excerpt">{material.text.slice(0, 460)}{material.text.length > 460 ? "…" : ""}</div>}</div><div className="authority-box"><div><ShieldCheck size={15} /><strong>{material.origin === "historical" ? "官方原件已人工核验" : "用户标注的来源 · 身份待核验"}</strong></div><p>{material.origin === "historical" ? "留存内容为人工核验摘要与必要短引，完整公告请查看原件。拟议安排仍需区分计划与已发生事实。" : "来源类型由导入者选择，尚未核验链接及发布主体。引用只核对导入文本，不代表来源身份已经证实。"}</p><span>权重依据来源身份，不是概率评分</span></div><div className="source-link-box"><span>来源原件 · 人工核验入口</span><a href={safeUrl(material.sourceUrl)} target="_blank" rel="noreferrer"><span>{sourceHost(material.sourceUrl)}</span><ExternalLink size={14} /></a>{material.pageHint && <small><BookOpen size={12} />原件定位：{material.pageHint}</small>}<p>链接用于人工核查，未自动抓取网页。</p></div><details className="raw-material"><summary>查看导入正文<ChevronDown size={14} /></summary><div>{material.text}</div></details><div className="evidence-foot"><ShieldCheck size={13} />引用匹配导入文本，历史版本不覆盖。</div></> : <div className="evidence-placeholder"><FileCheck2 size={32} /><h3>暂无材料</h3><p>选择一份材料，查看引用、来源与时间。</p><div><span>文本引用</span><span>来源身份</span><span>披露时间</span></div></div>}</aside>
      </div>
    </div>
    {evidenceOpen && <button className="evidence-scrim" aria-label="关闭证据面板" onClick={() => setEvidenceOpen(false)} />}
    {toast && <div className="toast" role="status"><CheckCheck size={17} />{toast}<button aria-label="关闭提示" onClick={() => setToast("")}><X size={14} /></button></div>}
    {modal && <div className="modal-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) setModal(null); }}><div className={`modal ${modal === "import" ? "import-modal" : ""}`} ref={modalRef} tabIndex={-1} role="dialog" aria-modal="true" aria-labelledby="modal-title"><div className="modal-heading"><div><h2 id="modal-title">{modal === "import" ? "添加材料" : modal === "settings" ? "服务与研究空间" : "关于知序"}</h2></div><button className="icon-button" aria-label="关闭对话框" onClick={() => setModal(null)}><X size={20} /></button></div>{modal === "import" ? <><p className="modal-description">按材料内容判断事件归属，存疑时由你确认。</p>{composer}</> : modal === "settings" ? <div className="settings-content"><div className="config-status"><span className={`config-icon ${config.configured ? "connected" : ""}`}>{config.configured ? <Check size={22} /> : <Settings2 size={22} />}</span><div><strong>{config.configured ? "分析服务可用" : "分析服务暂不可用"}</strong><p>{config.configured ? `${config.model} · 服务端分析` : "历史回放可正常浏览，已导入材料也会保留。"}</p></div></div><div className="setting-row"><span>研究空间</span><strong>{spaceStatus}</strong></div><div className="setting-row"><span>分析模型</span><strong>{config.model}</strong></div><div className="quota-summary"><div><span>{isGuest ? "本浏览器" : "当前研究空间"}今日剩余</span><strong>{loaded ? remainingAnalyses : "—"}<small>/ {config.dailyLimit} 次</small></strong></div><p>按北京时间每日重置 · 已用 {usedToday} 次</p></div><div className="setting-row"><span>演示站每日总分析上限</span><strong>{config.globalDailyLimit} 次</strong></div><p className="quota-site-note">所有研究空间共享站点额度，达到上限后次日恢复。这里展示上限，不表示站点实时剩余次数。</p><div className="space-privacy"><h3>{isGuest ? "无需登录的浏览器研究空间" : "研究空间与资料隐私"}</h3>{isGuest && <p>无需登录 · 资料随当前浏览器保存，换浏览器或清除 Cookie 无法找回。</p>}<p>资料实际保存在服务端，通过{isGuest ? "当前浏览器会话" : "当前研究空间"}关联。页面不公开个人账号信息。</p><p>进行 AI 分析时，导入的标题与正文会发送给分析服务；来源链接仅供人工核验。密钥由服务端管理。</p></div><button className="button primary" disabled={loading} onClick={async () => { await loadWorkspace(); setToast("服务与空间状态已刷新"); }}><RefreshCw size={15} className={loading ? "spin" : ""} />刷新服务与空间状态</button></div> : <div className="about-content"><p>知序是一个面向个人投资研究者的事件证据工作台。把同一事件的分散材料串联起来，看到新信息改变了什么，以及当前结论依赖哪些原文。</p><div className="about-principles"><span><FileCheck2 size={20} /><strong>证据先行</strong><small>引用指向导入文本</small></span><span><History size={20} /><strong>版本可溯</strong><small>新结论保留旧判断</small></span><span><ShieldCheck size={20} /><strong>边界清晰</strong><small>事实、观点与推测分开</small></span></div><p className="about-disclaimer">历史案例为真实公告的人工整理。AI 分析仅辅助提取与归并，研究结论应回到原始资料核验。产品不提供买卖建议或目标价。</p><button className="button primary" onClick={() => setModal(null)}>开始研究<ArrowRight size={14} /></button></div>}</div></div>}
  </div>;
}
