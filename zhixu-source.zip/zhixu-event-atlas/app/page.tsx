"use client";

import { useEffect, useRef, useState, type ChangeEvent, type FormEvent } from "react";
import { ArrowDown, ArrowRight, Bell, BookOpen, Check, CheckCheck, ChevronDown, ChevronRight, CircleAlert, Clock3, ExternalLink, FileCheck2, FileJson, FilePlus2, FileText, GitBranch, History, Layers3, LoaderCircle, Plus, RefreshCw, Search, Settings2, ShieldCheck, Sparkles, Upload, X } from "lucide-react";
import { demoState, sampleMaterials } from "../lib/fixtures";
import type { Claim, EventStatus, Material, MaterialInput, Relation, SourceKind, Version, WorkspaceResponse, WorkspaceState } from "../lib/types";

const statusLabels: Record<EventStatus, string> = { planning: "筹划中", progress: "推进中", completed: "已完成", terminated: "已终止", denied: "已否认", uncertain: "待核实", expired: "时效已更新" };
const relationLabels: Record<Relation, string> = { initial: "首次披露", supports: "支持原结论", supplements: "补充证据", contradicts: "证据冲突", corrects: "更正披露", denies: "否认原陈述", progresses: "状态推进" };
const sourceLabels: Record<SourceKind, string> = { official: "官方公告", media: "媒体报道", research: "研究资料", other: "其他来源" };
const kindLabels = { fact: "事实", opinion: "观点", inference: "推测", rumor: "传闻" };
const emptyState: WorkspaceState = { schemaVersion: 1, materials: [], events: [], notifications: [], runs: [], usage: { day: "", count: 0 }, activeRun: null };
const emptyForm: MaterialInput = { title: "", text: "", sourceUrl: "", sourceKind: "official", publishedAt: null };
const tabs = ["时间线", "证据", "版本", "调用记录"] as const;
type Tab = typeof tabs[number];
type Modal = "import" | "settings" | "about" | null;

function dateLabel(value: string | null | undefined, full = false) {
  if (!value) return "未知";
  if (/^\d{4}-\d{2}-\d{2}$/.test(value)) return value.replaceAll("-", ".");
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat("zh-CN", { timeZone: "Asia/Shanghai", year: "numeric", month: "2-digit", day: "2-digit", ...(full ? { hour: "2-digit", minute: "2-digit", hour12: false } : {}) }).format(date).replaceAll("/", ".");
}
function shanghaiDay() { const parts = new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Shanghai", year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(new Date()); return ["year", "month", "day"].map(kind => parts.find(part => part.type === kind)?.value).join("-"); }
function safeUrl(value: string) { try { const url = new URL(value); return ["http:", "https:"].includes(url.protocol) ? url.href : undefined; } catch { return undefined; } }
function sourceHost(value: string) { try { return new URL(value).hostname.replace(/^www\./, ""); } catch { return "原始材料"; } }
function Status({ status }: { status: EventStatus }) { return <span className={`status status-${status}`}><i />{statusLabels[status]}</span>; }
function Provenance({ version }: { version?: Version }) { return <span className="provenance">{version?.provenance === "deepseek" ? <Sparkles size={12} /> : <ShieldCheck size={12} />}{version?.provenance === "deepseek" ? "AI 分析 · 文本引用已校验" : version?.provenance === "expiry" ? "规则检查 · 时效更新" : "人工核验"}</span>; }

export default function Home() {
  const [mode, setMode] = useState<"history" | "research">("history");
  const [workspace, setWorkspace] = useState<WorkspaceState>(emptyState);
  const [config, setConfig] = useState({ configured: false, authenticated: false, model: "DeepSeek", identityKind: "guest" as "guest" | "account", dailyLimit: 5, globalDailyLimit: 50 });
  const [loaded, setLoaded] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [toast, setToast] = useState("");
  const [busy, setBusy] = useState<string | null>(null);
  const [eventId, setEventId] = useState<string | null>(null);
  const [versionNumber, setVersionNumber] = useState<number | null>(null);
  const [materialId, setMaterialId] = useState<string | null>(null);
  const [tab, setTab] = useState<Tab>("时间线");
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [modal, setModal] = useState<Modal>(null);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [evidenceOpen, setEvidenceOpen] = useState(false);
  const [form, setForm] = useState<MaterialInput>(emptyForm);
  const [formError, setFormError] = useState("");
  const [analyzeAfterImport, setAnalyzeAfterImport] = useState(true);
  const [mobileNav, setMobileNav] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const modalRef = useRef<HTMLDivElement>(null);
  const state = mode === "history" ? demoState : workspace;
  const filteredEvents = state.events.filter(event => (statusFilter === "all" || event.status === statusFilter) && `${event.title} ${event.companies.map(company => `${company.name} ${company.code}`).join(" ")}`.toLowerCase().includes(query.toLowerCase()));
  const event = state.events.find(item => item.id === eventId) ?? filteredEvents[0] ?? state.events[0];
  const versions = event?.versions ?? [];
  const latestVersion = versions[versions.length - 1];
  const version = versions.find(item => item.number === versionNumber) ?? latestVersion;
  const isHistoricalVersion = !!version && !!latestVersion && version.id !== latestVersion.id;
  const visibleVersions = versions.filter(item => !version || item.number <= version.number);
  const visibleMaterialIds = new Set(visibleVersions.map(item => item.materialId));
  const materials = state.materials.filter(item => event?.materialIds.includes(item.id) && (mode !== "history" || visibleMaterialIds.has(item.id)));
  const material = state.materials.find(item => item.id === materialId) ?? state.materials.find(item => item.id === version?.materialId) ?? materials[0];
  const claims = version?.claims ?? [];
  const materialClaims = [...new Map(visibleVersions.flatMap(item => item.claims).filter(claim => claim.materialId === material?.id).map(claim => [claim.id, claim])).values()];
  const pending = workspace.materials.filter(item => ["pending", "failed", "review"].includes(item.status));
  const unread = state.notifications.filter(item => !item.read).length;
  const usedToday = workspace.usage.day === shanghaiDay() ? workspace.usage.count : 0;
  const remainingAnalyses = Math.max(0, config.dailyLimit - usedToday);
  const canAnalyze = config.authenticated && config.configured && remainingAnalyses > 0;
  const isGuest = config.identityKind === "guest";
  const spaceStatus = config.authenticated ? (isGuest ? "游客空间已连接" : "研究空间已连接") : loading || (!loaded && !error) ? "研究空间连接中" : "研究空间连接失败，请刷新";
  const shownStatus = version?.status ?? event?.status;
  const evidenceCount = new Set(claims.map(claim => claim.materialId)).size;

  async function loadWorkspace(preserveError = false) {
    setLoading(true); if (!preserveError) setError("");
    try {
      const response = await fetch("/api/workspace", { cache: "no-store" });
      const data = await response.json() as WorkspaceResponse & { error?: string };
      if (!response.ok) throw new Error(data.error || "研究空间暂时无法读取");
      setWorkspace(data.state); setConfig({ configured: data.configured, authenticated: data.authenticated, model: data.model, identityKind: data.identityKind, dailyLimit: data.dailyLimit, globalDailyLimit: data.globalDailyLimit }); setLoaded(true);
    } catch (cause) { if (!preserveError) setError(cause instanceof Error ? cause.message : "连接失败，请重试"); }
    finally { setLoading(false); }
  }
  useEffect(() => { void loadWorkspace(); }, []);
  useEffect(() => { if (!toast) return; const timer = setTimeout(() => setToast(""), 4200); return () => clearTimeout(timer); }, [toast]);
  useEffect(() => {
    if (!modal && !evidenceOpen && !mobileNav && !notificationsOpen) return;
    function closeOnEscape(e: KeyboardEvent) { if (e.key === "Escape") { setModal(null); setEvidenceOpen(false); setMobileNav(false); setNotificationsOpen(false); } }
    window.addEventListener("keydown", closeOnEscape);
    if (modal) modalRef.current?.focus();
    return () => window.removeEventListener("keydown", closeOnEscape);
  }, [modal, evidenceOpen, mobileNav, notificationsOpen]);

  async function mutate(path: string, body: unknown, key: string): Promise<{ state: WorkspaceState; material?: Material } | null> {
    setBusy(key); setError("");
    try {
      const response = await fetch(`/api/${path}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
      const data = await response.json() as { state: WorkspaceState; material?: Material; error?: string };
      if (!response.ok) throw new Error(data.error || "操作失败，请稍后重试");
      setWorkspace(data.state); return data;
    } catch (cause) { setError(cause instanceof Error ? cause.message : "操作失败，请稍后重试"); return null; }
    finally { setBusy(null); }
  }
  function switchMode(next: "history" | "research") { setMode(next); setEventId(null); setVersionNumber(null); setMaterialId(null); setQuery(""); setStatusFilter("all"); setTab("时间线"); setMobileNav(false); setError(""); }
  function selectEvent(nextId: string) { setEventId(nextId); setVersionNumber(null); setMaterialId(null); setMobileNav(false); }
  function selectVersion(next: Version) { setVersionNumber(next.number); setMaterialId(next.materialId); }
  function inspectMaterial(id: string) { setMaterialId(id); setEvidenceOpen(true); }
  function openImport() { if (mode !== "research") switchMode("research"); setFormError(""); setModal("import"); }
  async function analyze(id: string) {
    const result = await mutate("analyze", { materialId: id }, `analyze-${id}`);
    if (result) {
      const updated = result.state.materials.find(item => item.id === id);
      if (updated?.eventId) { setEventId(updated.eventId); setVersionNumber(null); setMaterialId(id); }
      setToast(updated?.status === "review" ? "分析完成，事件归属需要你确认" : "分析已完成，结论与证据已更新");
    } else { await loadWorkspace(true); }
  }
  async function submitMaterial(e: FormEvent) {
    e.preventDefault(); setFormError("");
    if (form.title.trim().length < 2 || form.text.trim().length < 20 || !safeUrl(form.sourceUrl)) { setFormError("请填写至少 2 字标题、20 字正文和有效的 http / https 原始链接。"); return; }
    const result = await mutate("materials", form, "import");
    if (result?.material) {
      setModal(null); setForm(emptyForm); setMaterialId(result.material.id); setToast("材料已保存，导入文本已留存供核验");
      if (analyzeAfterImport && canAnalyze && result.material.status !== "analyzed") await analyze(result.material.id);
    }
  }
  async function importFile(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]; if (!file) return;
    try {
      if (file.size > 80 * 1024) throw new Error("文件超过 80 KB，请精简为与事件有关的文本后重试。");
      const text = await file.text();
      if (file.name.toLowerCase().endsWith(".json")) {
        const parsed = JSON.parse(text);
        if (!parsed || typeof parsed.title !== "string" || typeof parsed.text !== "string") throw new Error("JSON 需包含 title、text 字段，可选 sourceUrl、sourceKind、publishedAt。");
        setForm({ title: parsed.title, text: parsed.text, sourceUrl: typeof parsed.sourceUrl === "string" ? parsed.sourceUrl : "", sourceKind: ["official", "media", "research", "other"].includes(parsed.sourceKind) ? parsed.sourceKind : "other", publishedAt: typeof parsed.publishedAt === "string" ? parsed.publishedAt : null });
      } else { setForm(current => ({ ...current, title: current.title || file.name.replace(/\.txt$/i, ""), text })); }
      setFormError("");
    } catch (cause) { setFormError(cause instanceof Error ? cause.message : "文件无法读取，请选择 UTF-8 文本或 JSON 文件。"); }
    finally { e.target.value = ""; }
  }
  async function seedWorkspace() {
    const result = await mutate("seed", {}, "seed");
    if (result) { setEventId(result.state.events[0]?.id ?? null); setToast("历史案例的前两份材料已加入研究空间"); }
  }
  async function resolve(id: string, target: string | null) {
    const result = await mutate("resolve", { materialId: id, eventId: target }, `resolve-${id}`);
    if (result) { const updated = result.state.materials.find(item => item.id === id); setEventId(updated?.eventId ?? null); setVersionNumber(null); setMaterialId(id); setToast(target ? "已确认归入该事件" : "已创建独立事件"); }
  }
  async function readNotice(id?: string) { const result = await mutate("notifications/read", id ? { id } : {}, "notice"); if (result && !id) setToast("提醒已全部标为已读"); }

  const visibleRuns = mode === "research" ? state.runs : state.runs.filter(run => event?.materialIds.includes(run.materialId));
  const runPanel = <div className="runs-panel" role="tabpanel"><div className="timeline-heading"><span>分析过程，留有记录。</span><span>{mode === "research" ? "整个研究空间 · 含未归属材料" : "不展示模型内部推理"}</span></div>{visibleRuns.length ? visibleRuns.slice().reverse().map(run => <article className="run-card" key={run.id}><div><span className={`run-status ${run.status}`}><i />{run.status === "success" ? "分析成功" : run.status === "review" ? "等待归属确认" : "分析失败"}</span><time>{dateLabel(run.createdAt, true)}</time></div><strong>{run.model}</strong><p>{state.materials.find(item => item.id === run.materialId)?.title || run.materialId}</p><button className="text-button" onClick={() => inspectMaterial(run.materialId)}>查看导入文本<ArrowRight size={13} /></button><dl><div><dt>提示词版本</dt><dd>{run.promptVersion}</dd></div><div><dt>耗时</dt><dd>{(run.durationMs / 1000).toFixed(1)} 秒</dd></div><div><dt>Token 用量</dt><dd>{run.usage?.total_tokens?.toLocaleString() ?? "未记录"}</dd></div></dl>{run.error && <p className="run-error">{run.error}</p>}</article>) : <div className="quiet-empty"><ShieldCheck size={28} /><h3>{mode === "history" ? "这是人工核验的历史记录" : "暂无 AI 调用记录"}</h3><p>{mode === "history" ? "案例内容源自真实公告的人工整理，没有冒充 AI 生成。" : "完成一次真实分析后，将显示模型、耗时和用量。"}</p></div>}</div>;

  return <div className="workbench">
    {mobileNav && <button className="nav-scrim" aria-label="关闭导航" onClick={() => setMobileNav(false)} />}
    <aside className={`sidebar ${mobileNav ? "sidebar-open" : ""}`}>
      <a className="brand" href="/" aria-label="知序首页"><span className="brand-symbol"><i /><i /><i /></span><span>知序<small>让信息，形成脉络</small></span></a>
      <div className="sidebar-section-label">RESEARCH WORKSPACE</div>
      <button className="nav-item nav-active" onClick={() => { setTab("时间线"); setMobileNav(false); }}><Layers3 size={17} /><span>事件研究台</span><span className="nav-count">{state.events.length.toString().padStart(2, "0")}</span></button>
      <button className="nav-item" onClick={() => { setTab("证据"); setMobileNav(false); }}><FileText size={17} /><span>材料与证据</span><span className="nav-count">{state.materials.length.toString().padStart(2, "0")}</span></button>
      <button className={`nav-item ${tab === "调用记录" ? "nav-active" : ""}`} onClick={() => { setTab("调用记录"); setMobileNav(false); }}><Sparkles size={17} /><span>分析调用记录</span><span className="nav-count">{state.runs.length.toString().padStart(2, "0")}</span></button><div className="sidebar-divider" />
      <div className="sidebar-list-heading"><span>关注的事件</span><button aria-label="导入材料以添加事件" onClick={openImport}><Plus size={16} /></button></div>
      <div className="sidebar-search"><Search size={14} /><input aria-label="搜索公司或事件" placeholder="搜索公司 / 事件" value={query} onChange={e => setQuery(e.target.value)} /><span>⌕</span></div>
      <label className="sidebar-filter"><span>事件状态</span><select aria-label="筛选事件状态" value={statusFilter} onChange={e => setStatusFilter(e.target.value)}><option value="all">全部状态</option>{Object.entries(statusLabels).map(([key, label]) => <option value={key} key={key}>{label}</option>)}</select><ChevronDown size={12} /></label>
      <div className="event-index">{filteredEvents.map((item, index) => <button key={item.id} className={`event-index-item ${item.id === event?.id ? "selected" : ""}`} onClick={() => selectEvent(item.id)}><span className="index-number">{String(index + 1).padStart(2, "0")}</span><span className="index-text"><strong>{item.companies.map(company => company.name).join(" × ") || item.title}</strong><span>{item.category}<i />{statusLabels[item.status]}</span></span><ChevronRight size={13} /></button>)}{filteredEvents.length === 0 && <p className="sidebar-empty">{state.events.length ? "没有匹配的事件" : "导入材料，建立第一条事件脉络。"}</p>}</div>
      <div className="sidebar-bottom"><div className="research-note"><span className="note-dot" /><span>少一点噪声，<br />多一点有据可循。</span></div><button className="sidebar-settings" onClick={() => setModal("settings")}><Settings2 size={16} /><span>服务与空间</span><span className={`connection-dot ${config.configured ? "connected" : ""}`} /></button><button className="sidebar-settings" onClick={() => setModal("about")}><BookOpen size={16} /><span>关于知序</span><ExternalLink size={13} /></button><div className="sidebar-user"><span>研</span><div>个人研究空间<small>PERSONAL RESEARCH</small></div><ShieldCheck size={16} /></div></div>
    </aside>

    <div className="workspace-main">
      <header className="topbar"><div className="breadcrumb"><button className="mobile-menu icon-button" aria-label="打开导航" onClick={() => setMobileNav(true)}><Layers3 size={19} /></button><span>研究工作台</span><ChevronRight size={13} /><strong>事件详情</strong></div><div className="topbar-actions"><div className="mode-toggle" aria-label="工作模式"><button className={mode === "history" ? "active" : ""} onClick={() => switchMode("history")}>历史回放</button><button className={mode === "research" ? "active" : ""} onClick={() => switchMode("research")}>我的研究</button></div><div className="notification-wrap"><button className="icon-button notification-button" aria-label={`站内提醒，${unread} 条未读`} aria-expanded={notificationsOpen} onClick={() => setNotificationsOpen(!notificationsOpen)}><Bell size={19} />{unread > 0 && <i />}</button>{notificationsOpen && <div className="notifications"><div className="popover-heading"><strong>事件动态</strong><button onClick={() => mode === "research" ? void readNotice() : setToast("历史回放中的提醒为只读记录")}><CheckCheck size={14} />全部已读</button></div>{state.notifications.length ? state.notifications.slice().reverse().map(notice => <button className={`notice ${notice.read ? "read" : ""}`} key={notice.id} onClick={() => { selectEvent(notice.eventId); if (mode === "research") void readNotice(notice.id); setNotificationsOpen(false); }}><span className="notice-dot" /><span><strong>{notice.title}</strong><p>{notice.body}</p><small>{dateLabel(notice.createdAt, true)}</small></span></button>) : <div className="popover-empty">暂无事件动态。实质变化会在这里提醒你。</div>}<p className="popover-foot">仅站内提醒 · 不发送外部通知</p></div>}</div><span className="topbar-divider" /><button className="button primary import-top" onClick={openImport}><Plus size={16} />导入材料</button></div></header>
      {error && <div className="global-error" role="alert"><CircleAlert size={17} /><span>{error}</span><button onClick={() => void loadWorkspace()}>重新连接</button><button className="icon-button" aria-label="关闭错误信息" onClick={() => setError("")}><X size={15} /></button></div>}
      <div className="content-grid">
        <main className="research-content">
          <div className="page-eyebrow"><span><i />INVESTMENT EVENT INTELLIGENCE</span><span className="eyebrow-trailing">证据先行，结论有序</span></div>
          <div className="page-heading"><div><h1>投资事件证据台<span> / </span></h1><p>把分散的披露，串成可追溯的事件脉络。</p></div><span className="workspace-number">01<span>— EVENT ATLAS</span></span></div>
          <div className={`mode-banner ${mode === "research" ? "research-banner" : ""}`}><span>{mode === "history" ? <History size={16} /> : <Sparkles size={16} />}<strong>{mode === "history" ? "人工核验 · 历史回放" : !config.authenticated ? spaceStatus : "我的研究 · 真实分析"}</strong><span>{mode === "history" ? "真实公告整理，回看结论如何演变" : config.authenticated ? `${isGuest ? "无需登录" : "研究空间"} · 今日剩余 ${remainingAnalyses} / ${config.dailyLimit} 次分析` : loading || (!loaded && !error) ? "正在关联当前浏览器的研究空间" : "请刷新，重新连接研究空间"}</span></span><button disabled={mode === "research" && loading} onClick={() => mode === "history" ? switchMode("research") : !config.authenticated ? void loadWorkspace() : setModal("settings")}>{mode === "history" ? "进入我的研究" : !config.authenticated ? "刷新连接" : "服务与额度"}<ArrowRight size={14} /></button></div>
          {mode === "research" && config.authenticated && isGuest && <div className="guest-space-note"><ShieldCheck size={14} /><p>无需登录 · 资料随当前浏览器保存，换浏览器或清除 Cookie 无法找回。<span>数据存于服务端，以当前浏览器会话关联。</span></p><button onClick={() => setModal("settings")}>今日剩余 {remainingAnalyses} 次<ChevronRight size={13} /></button></div>}

          {mode === "research" && !loaded && <div className="loading-card"><LoaderCircle className="spin" size={23} /><p>{loading ? "正在读取研究空间…" : "研究空间暂时无法读取"}</p>{!loading && <button className="button secondary" onClick={() => void loadWorkspace()}>重新加载</button>}</div>}
          {mode === "research" && loaded && !event && tab !== "调用记录" && <section className="empty-workspace"><div className="empty-symbol"><GitBranch size={35} /></div><span className="section-kicker">YOUR FIRST RESEARCH</span><h2>每条脉络，从一份材料开始。</h2><p>导入公告、报道或研究资料，让关键事实、<br />证据关系与结论变化，有迹可循。</p><button className="button primary" onClick={openImport}><Plus size={16} />导入首份材料</button>{workspace.materials.length === 0 && <button className="text-button" disabled={busy === "seed"} onClick={() => void seedWorkspace()}>{busy === "seed" ? <LoaderCircle className="spin" size={14} /> : <History size={14} />}使用历史案例开始研究<ArrowRight size={14} /></button>}<div className="empty-guide"><span><b>01</b>导入原文</span><ChevronRight size={12} /><span><b>02</b>提取证据</span><ChevronRight size={12} /><span><b>03</b>追踪变化</span></div></section>}

          {mode === "research" && pending.length > 0 && <section className="pending-section"><div className="section-title"><span><CircleAlert size={15} />待处理材料</span><small>{pending.length} 份</small></div>{pending.map(item => <div className={`pending-card ${item.status === "review" ? "review-card" : ""}`} key={item.id}><div className="pending-heading"><FileText size={17} /><strong>{item.title}</strong><span className="tiny-badge">{item.status === "review" ? "待确认归属" : item.status === "failed" ? "分析失败" : "待分析"}</span></div>{item.status === "review" && item.proposedAnalysis ? <><p>{item.proposedAnalysis.rationale}</p><div className="review-proposal"><span>建议归入</span><strong>{workspace.events.find(event => event.id === item.proposedAnalysis?.suggestedEventId)?.title || "未找到候选事件，请独立建档"}</strong></div><div className="pending-actions">{item.proposedAnalysis.suggestedEventId && <button className="button primary small" disabled={!!busy} onClick={() => void resolve(item.id, item.proposedAnalysis!.suggestedEventId)}><Check size={14} />确认归入该事件</button>}<button className="button secondary small" disabled={!!busy} onClick={() => void resolve(item.id, null)}>作为独立事件</button><button className="text-button" onClick={() => inspectMaterial(item.id)}>查看原文<ArrowRight size={13} /></button></div></> : <><p>{item.error || "材料已保存，分析完成后将建立或更新事件时间线。"}</p><div className="pending-actions"><button className="button primary small" disabled={!!busy || !canAnalyze} onClick={() => void analyze(item.id)}>{busy === `analyze-${item.id}` ? <LoaderCircle className="spin" size={14} /> : <Sparkles size={14} />}{busy === `analyze-${item.id}` ? "正在分析…" : item.status === "failed" ? "重新分析" : "开始分析"}</button>{!config.configured && <button className="text-button" onClick={() => setModal("settings")}>查看服务状态<ArrowRight size={13} /></button>}{config.configured && remainingAnalyses === 0 && <span className="quota-exhausted">今日分析额度已用完，次日恢复</span>}<button className="text-button" onClick={() => inspectMaterial(item.id)}>查看原文</button></div></>}</div>)}</section>}

          {event && <>
            <section className="event-heading"><div className="event-metadata"><span className="category-label">{event.category}</span><span className="thin-separator" /><span>{mode === "history" ? "历史案例研究" : "个人研究事件"}</span><span className="event-reference">{event.id.slice(-8).toUpperCase()}</span></div><h2>{event.title}</h2><div className="company-row">{event.companies.map(company => <span className="company-chip" key={`${company.code}-${company.name}`}><span className="company-monogram">{company.name.slice(0, 1)}</span><strong>{company.name}</strong><span>{company.code}</span></span>)}<span className="company-note">直接参与主体</span></div></section>
            <section className="conclusion-card"><div className="conclusion-top"><span><span className="section-kicker">{isHistoricalVersion ? "HISTORICAL CONCLUSION" : "CURRENT CONCLUSION"}</span><strong>{isHistoricalVersion ? "当时结论" : "当前结论"}</strong></span>{shownStatus && <Status status={shownStatus} />}</div><p className="conclusion-summary">{version?.summary ?? event.summary}</p>{isHistoricalVersion && <div className="timeline-heading" style={{ margin: "0 0 16px" }}><span>正在回看 V{String(version.number).padStart(2, "0")} · 后续已有新结论</span><button className="text-button" onClick={() => { setVersionNumber(null); setMaterialId(latestVersion.materialId); }}>返回最新结论<ArrowRight size={13} /></button></div>}<div className="conclusion-bottom"><Provenance version={version} /><span><Clock3 size={12} />{version?.asOf ? "截至" : "结论更新"} {dateLabel(version?.asOf ?? version?.updatedAt ?? event.updatedAt)}</span><button onClick={() => setTab("证据")}>{evidenceCount || materials.length} 份依据<ArrowRight size={13} /></button></div>{version?.reason && <div className="change-note"><GitBranch size={14} /><span><strong>{version.relation === "initial" ? "建档依据" : "本次变化"}</strong>{version.reason}</span></div>}</section>
            {mode === "history" && versions.length > 1 && <section className="replay-strip" aria-label="历史阶段回放"><div className="replay-label"><History size={14} /><span>回到当时</span></div><div className="replay-steps">{versions.map((item, index) => <button key={item.id} className={`${version?.id === item.id ? "active" : ""} ${item.number < (version?.number ?? 0) ? "passed" : ""}`} onClick={() => selectVersion(item)}><span className="step-node">{item.number < (version?.number ?? 0) ? <Check size={10} /> : index + 1}</span><span><strong>{statusLabels[item.status]}</strong><small>{dateLabel(item.asOf ?? item.updatedAt)}</small></span></button>)}</div></section>}
            <div className="detail-tabs"><div role="tablist" aria-label="事件详情">{tabs.map(label => <button key={label} role="tab" aria-selected={tab === label} className={tab === label ? "active" : ""} onClick={() => setTab(label)}>{label}{label === "时间线" && <span>{visibleVersions.length.toString().padStart(2, "0")}</span>}{label === "证据" && <span>{materials.length.toString().padStart(2, "0")}</span>}</button>)}</div>{mode === "research" && <button className="refresh-button" disabled={!!busy} onClick={async () => { const result = await mutate("expire", {}, "expire"); if (result) setToast("明确有效期已检查，历史事实继续保留"); }}><RefreshCw size={13} className={busy === "expire" ? "spin" : ""} />检查时效</button>}</div>
            {tab === "时间线" && <div className="timeline-panel" role="tabpanel"><div className="timeline-heading"><span>每一次变化，都保留依据。</span><span><ArrowDown size={12} />按结论版本倒序</span></div><div className="timeline">{visibleVersions.slice().reverse().map((item, index) => { const source = state.materials.find(material => material.id === item.materialId); return <article className={`timeline-item ${index === 0 ? "latest" : ""}`} key={item.id}><div className="timeline-marker"><span>{index === 0 ? <GitBranch size={14} /> : <span />}</span><time>{dateLabel(source?.publishedAt ?? item.asOf ?? item.updatedAt)}</time><small>{source?.publishedAt ? "披露日期" : item.asOf ? "结论截至日" : "结论更新日"}</small></div><div className="timeline-card"><div className="timeline-card-top"><span className={`relation-label relation-${item.relation}`}>{relationLabels[item.relation]}</span><span className="version-tag">V{String(item.number).padStart(2, "0")}</span>{index === 0 && <span className="latest-label">{item.id === latestVersion?.id ? "最新版本" : "回放节点"}</span>}</div><h3>{source?.title ?? statusLabels[item.status]}</h3><p>{item.summary}</p>{item.claims[0] && <button className="quote-preview" onClick={() => inspectMaterial(item.claims[0].materialId)}><span>“</span><span>{item.claims[0].quote}</span><ArrowRight size={14} /></button>}<div className="timeline-card-bottom"><span><ShieldCheck size={12} />{source ? `${source.origin === "user" ? "用户标注 · " : ""}${sourceLabels[source.sourceKind]}` : "保留的历史证据"}</span><span>披露 {dateLabel(source?.publishedAt)}</span><button onClick={() => inspectMaterial(item.materialId)}>查看证据<ArrowRight size={13} /></button></div></div></article>; })}</div><div className="timeline-end"><span />脉络始于首次公开披露</div></div>}
            {tab === "证据" && <div className="evidence-list-panel" role="tabpanel"><div className="timeline-heading"><span>导入文本留存，结论可核。</span><span>{materials.length} 份材料</span></div>{materials.map((item, index) => <button className={`evidence-list-card ${material?.id === item.id ? "selected" : ""}`} key={item.id} onClick={() => inspectMaterial(item.id)}><span className="evidence-file-icon"><FileText size={21} /></span><span className="evidence-list-copy"><small>{item.origin === "historical" ? sourceLabels[item.sourceKind] : `用户标注 · ${sourceLabels[item.sourceKind]}`}<i />{dateLabel(item.publishedAt)}</small><strong>{item.title}</strong><span>{sourceHost(item.sourceUrl)}{item.pageHint ? ` · ${item.pageHint}` : " · 导入文本留存"}</span></span><span className="evidence-list-number">{String(index + 1).padStart(2, "0")}</span><ChevronRight size={16} /></button>)}<div className="source-explanation"><ShieldCheck size={18} /><span><strong>来源权威性，不等于实现概率。</strong><p>权重依据来源身份、原文直接程度与独立证据。官方预案表达拟议安排，不表示交易一定完成。</p></span></div></div>}
            {tab === "版本" && <div className="versions-panel" role="tabpanel"><div className="timeline-heading"><span>新结论出现，旧判断仍然可见。</span><span>不可变版本快照</span></div>{versions.slice().reverse().map(item => <article className="version-card" key={item.id}><div className="version-card-heading"><span className="version-large">V{String(item.number).padStart(2, "0")}</span><Status status={item.status} /><span>{dateLabel(item.updatedAt, true)}</span></div><p>{item.summary}</p><div className="version-reason"><GitBranch size={13} />{relationLabels[item.relation]} · {item.reason}</div><div className="version-card-foot"><Provenance version={item} /><button onClick={() => { selectVersion(item); setTab("时间线"); }}>回看此版本<ArrowRight size={13} /></button></div></article>)}</div>}
            {tab === "调用记录" && runPanel}
          </>}
          {mode === "research" && loaded && !event && <><div className="detail-tabs"><div role="tablist" aria-label="研究空间记录"><button role="tab" aria-selected={tab === "调用记录"} className={tab === "调用记录" ? "active" : ""} onClick={() => setTab("调用记录")}>调用记录<span>{visibleRuns.length.toString().padStart(2, "0")}</span></button></div><span className="calls-scope">整个研究空间</span></div>{tab === "调用记录" && runPanel}</>}
          <footer className="content-footer"><span className="footer-wordmark">知序 <i>ZHIXU</i></span><p>辅助事实研究，不提供买卖建议或目标价。信息以原始披露为准。</p><span>有据 · 有序</span></footer>
        </main>

        <aside className={`evidence-panel ${evidenceOpen ? "evidence-open" : ""}`} aria-label="导入材料与来源面板"><div className="evidence-panel-heading"><span><FileCheck2 size={17} /><strong>证据核验</strong></span><button className="icon-button close-evidence" aria-label="关闭证据面板" onClick={() => setEvidenceOpen(false)}><X size={18} /></button><span className="evidence-live">导入文本留存</span></div>{material ? <><div className="evidence-document-heading"><div><span className="document-file"><FileText size={21} /></span><span className="source-badge">{material.origin === "historical" ? sourceLabels[material.sourceKind] : `用户标注 · ${sourceLabels[material.sourceKind]}`}</span></div><h3>{material.title}</h3><span className="document-origin">{material.origin === "historical" ? "人工核验摘要 · 附原件短引" : "用户导入文本 · 来源身份待核验"}</span></div><div className="document-date-grid"><div><span>发生时间</span><strong>{dateLabel(material.occurredAt)}</strong></div><div><span>披露时间</span><strong>{dateLabel(material.publishedAt)}</strong></div><div><span>抓取时间</span><strong>{material.fetchedAt ? dateLabel(material.fetchedAt, true) : "未自动抓取"}</strong></div><div><span>导入时间</span><strong>{dateLabel(material.ingestedAt, true)}</strong></div></div><div className="evidence-section-label"><span>关键证据摘录</span><small>{materialClaims.length || "导入文本"}</small></div><div className="claim-list">{materialClaims.length ? materialClaims.map((claim: Claim) => <article className="claim-card" key={claim.id}><span className={`claim-kind kind-${claim.kind}`}>{kindLabels[claim.kind]}</span>{claim.expired && <span className="expired-claim">已过有效期</span>}<p>“{claim.quote}”</p><span className="claim-description">{claim.text}</span>{claim.validUntil && <small>明确有效期至 {dateLabel(claim.validUntil)}</small>}</article>) : <div className="raw-excerpt">{material.text.slice(0, 460)}{material.text.length > 460 ? "…" : ""}</div>}</div><div className="authority-box"><div><ShieldCheck size={15} /><strong>{material.origin === "historical" ? "官方原件已人工核验" : "用户标注的来源 · 身份待核验"}</strong></div><p>{material.origin === "historical" ? "留存内容为人工核验摘要与必要短引，完整公告请查看原件。拟议安排仍需区分计划与已发生事实。" : "来源类型由导入者选择，尚未核验链接及发布主体。引用只核对导入文本，不代表来源身份已经证实。"}</p><span>权重依据来源身份，不是概率评分</span></div><div className="source-link-box"><span>来源原件 · 人工核验入口</span><a href={safeUrl(material.sourceUrl)} target="_blank" rel="noreferrer"><span>{sourceHost(material.sourceUrl)}</span><ExternalLink size={14} /></a>{material.pageHint && <small><BookOpen size={12} />原件定位：{material.pageHint}</small>}<p>链接用于人工核查，未自动抓取网页。</p></div><details className="raw-material"><summary>查看导入正文<ChevronDown size={14} /></summary><div>{material.text}</div></details><div className="evidence-foot"><ShieldCheck size={13} />引用匹配导入文本，历史版本不覆盖。</div></> : <div className="evidence-placeholder"><FileCheck2 size={32} /><h3>让每个判断，有据可循。</h3><p>导入材料后，在这里核查<br />关键引用、来源与时间。</p><div><span>文本引用</span><span>来源身份</span><span>披露时间</span></div></div>}</aside>
      </div>
    </div>
    {evidenceOpen && <button className="evidence-scrim" aria-label="关闭证据面板" onClick={() => setEvidenceOpen(false)} />}
    {toast && <div className="toast" role="status"><CheckCheck size={17} />{toast}<button aria-label="关闭提示" onClick={() => setToast("")}><X size={14} /></button></div>}
    {modal && <div className="modal-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) setModal(null); }}><div className={`modal ${modal === "import" ? "import-modal" : ""}`} ref={modalRef} tabIndex={-1} role="dialog" aria-modal="true" aria-labelledby="modal-title" onKeyDown={e => { if (e.key === "Tab") { const elements = modalRef.current?.querySelectorAll<HTMLElement>('button:not([disabled]), input, select, textarea, a[href], [tabindex="0"]'); if (!elements?.length) return; const first = elements[0], last = elements[elements.length - 1]; if (document.activeElement === modalRef.current) { e.preventDefault(); (e.shiftKey ? last : first).focus(); return; } if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); } else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); } } }}><div className="modal-heading"><div><span className="section-kicker">{modal === "import" ? "ADD NEW MATERIAL" : modal === "settings" ? "ANALYSIS SETTINGS" : "ABOUT ZHIXU"}</span><h2 id="modal-title">{modal === "import" ? "导入一份新材料" : modal === "settings" ? "服务与研究空间" : "让信息，形成脉络。"}</h2></div><button className="icon-button" aria-label="关闭对话框" onClick={() => setModal(null)}><X size={20} /></button></div>{modal === "import" ? <form onSubmit={submitMaterial}><p className="modal-description">留存导入文本与来源链接，让每一次结论变化都能回溯。</p>{!config.authenticated && <div className="space-connect-callout"><ShieldCheck size={16} /><span>{spaceStatus}。可先整理材料，连接后保存。</span><button type="button" disabled={loading} onClick={() => void loadWorkspace()}>刷新连接<RefreshCw size={13} /></button></div>}<div className="import-tools"><button className="file-upload" type="button" onClick={() => fileRef.current?.click()}><Upload size={16} /><span>选择 TXT / JSON · ≤80 KB</span><FileJson size={15} /></button><input ref={fileRef} type="file" accept=".txt,.json,text/plain,application/json" onChange={importFile} hidden /><button type="button" className="sample-button" onClick={() => { const sample = sampleMaterials[2]; if (sample) { setForm({ title: sample.title, text: sample.text, sourceUrl: sample.sourceUrl, sourceKind: sample.sourceKind, publishedAt: sample.publishedAt }); setFormError(""); } }}>填入终止公告样本<ArrowDown size={12} /></button></div><label className="field"><span>材料标题 <i>*</i></span><input required maxLength={160} placeholder="例如：关于终止重大资产重组的公告" value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} /></label><div className="form-row"><label className="field"><span>来源类型</span><select value={form.sourceKind} onChange={e => setForm({ ...form, sourceKind: e.target.value as SourceKind })}>{Object.entries(sourceLabels).map(([key, label]) => <option value={key} key={key}>{label}</option>)}</select></label><label className="field"><span>披露日期 <small>未知可留空</small></span><input type="date" value={form.publishedAt?.slice(0, 10) ?? ""} onChange={e => setForm({ ...form, publishedAt: e.target.value || null })} /></label></div><label className="field"><span>原始链接 <i>*</i></span><input type="url" required placeholder="https://…" value={form.sourceUrl} onChange={e => setForm({ ...form, sourceUrl: e.target.value })} /></label><label className="field"><span>材料正文 <i>*</i><small>{form.text.length.toLocaleString()} 字</small></span><textarea required rows={7} maxLength={20000} placeholder="粘贴需要分析的原文。仅导入文本，不会自动访问来源链接。" value={form.text} onChange={e => setForm({ ...form, text: e.target.value })} /></label><label className="checkbox-label"><input type="checkbox" checked={analyzeAfterImport} onChange={e => setAnalyzeAfterImport(e.target.checked)} disabled={!canAnalyze} /><span>保存后立即分析 <small>{canAnalyze ? `今日剩余 ${remainingAnalyses} 次 · ${config.model}` : !config.configured ? "分析服务暂不可用，当前仅保存材料" : remainingAnalyses === 0 ? "今日额度已用完，当前仅保存材料" : "研究空间连接后可用"}</small></span></label>{(formError || error) && <p className="form-error" role="alert"><CircleAlert size={15} />{formError || error}</p>}<div className="modal-actions"><span><ShieldCheck size={13} />密钥仅保存在服务端</span><button className="button secondary" type="button" onClick={() => setModal(null)}>取消</button><button className="button primary" type="submit" disabled={busy === "import" || !config.authenticated}>{busy === "import" ? <LoaderCircle className="spin" size={15} /> : <FilePlus2 size={15} />}{busy === "import" ? "正在保存…" : analyzeAfterImport && canAnalyze ? "导入并分析" : "保存材料"}</button></div></form> : modal === "settings" ? <div className="settings-content"><div className="config-status"><span className={`config-icon ${config.configured ? "connected" : ""}`}>{config.configured ? <Check size={22} /> : <Settings2 size={22} />}</span><div><strong>{config.configured ? "分析服务可用" : "分析服务暂不可用"}</strong><p>{config.configured ? `${config.model} · 服务端分析` : "历史回放可正常浏览，已导入材料也会保留。"}</p></div></div><div className="setting-row"><span>研究空间</span><strong>{spaceStatus}</strong></div><div className="setting-row"><span>分析模型</span><strong>{config.model}</strong></div><div className="quota-summary"><div><span>{isGuest ? "本浏览器" : "当前研究空间"}今日剩余</span><strong>{loaded ? remainingAnalyses : "—"}<small>/ {config.dailyLimit} 次</small></strong></div><p>按北京时间每日重置 · 已用 {usedToday} 次</p></div><div className="setting-row"><span>演示站每日总分析上限</span><strong>{config.globalDailyLimit} 次</strong></div><p className="quota-site-note">所有研究空间共享站点额度，达到上限后次日恢复。这里展示上限，不表示站点实时剩余次数。</p><div className="space-privacy"><h3>{isGuest ? "无需登录的浏览器研究空间" : "研究空间与资料隐私"}</h3>{isGuest && <p>无需登录 · 资料随当前浏览器保存，换浏览器或清除 Cookie 无法找回。</p>}<p>资料实际保存在服务端，通过{isGuest ? "当前浏览器会话" : "当前研究空间"}关联。页面不公开个人账号信息。</p><p>进行 AI 分析时，导入的标题与正文会发送给分析服务；来源链接仅供人工核验。密钥由服务端管理。</p></div><button className="button primary" disabled={loading} onClick={async () => { await loadWorkspace(); setToast("服务与空间状态已刷新"); }}><RefreshCw size={15} className={loading ? "spin" : ""} />刷新服务与空间状态</button></div> : <div className="about-content"><p>知序是一个面向个人投资研究者的事件证据工作台。把同一事件的分散材料串联起来，看到新信息改变了什么，以及当前结论依赖哪些原文。</p><div className="about-principles"><span><FileCheck2 size={20} /><strong>证据先行</strong><small>引用指向导入文本</small></span><span><History size={20} /><strong>版本可溯</strong><small>新结论保留旧判断</small></span><span><ShieldCheck size={20} /><strong>边界清晰</strong><small>事实、观点与推测分开</small></span></div><p className="about-disclaimer">历史案例为真实公告的人工整理。AI 分析仅辅助提取与归并，研究结论应回到原始资料核验。产品不提供买卖建议或目标价。</p><button className="button primary" onClick={() => setModal(null)}>开始研究<ArrowRight size={14} /></button></div>}</div></div>}
  </div>;
}
