import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "知序 · 投资事件证据台",
  description: "把分散的披露，串成可追溯的事件脉络。以原文为依据，追踪投资事件的结论、证据与版本变化。",
  icons: { icon: "/favicon.svg", shortcut: "/favicon.svg" },
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="zh-CN"><body>{children}</body></html>;
}
