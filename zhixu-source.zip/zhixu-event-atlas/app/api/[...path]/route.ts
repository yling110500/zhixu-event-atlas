import { env } from 'cloudflare:workers';
import { getChatGPTUser } from '../../chatgpt-auth';
import { AppError } from '../../../lib/domain';
import { analyzeWithDeepSeek } from '../../../lib/provider';
import { WorkspaceRepository } from '../../../lib/repository';
import { readMutationBody, WorkspaceService } from '../../../lib/service';
import { personalDailyLimit, resolveWorkspaceIdentity } from '../../../lib/identity';
import type { WorkspaceIdentity } from '../../../lib/identity';
import { configuredGlobalLimit, DailyUsageBudget } from '../../../lib/budget';

export const dynamic='force-dynamic';
const json=(body:unknown,status=200,cookie?:string)=>Response.json(body,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff',...(cookie?{'Set-Cookie':cookie}:{})}});
function settings(){return {key:env.DEEPSEEK_API_KEY,model:env.DEEPSEEK_MODEL||'deepseek-flash'};}
function service(identity:WorkspaceIdentity){
  if(!env.DB)throw new AppError('研究空间存储尚未配置，请联系管理员','STORAGE_UNAVAILABLE',503);
  return new WorkspaceService(new WorkspaceRepository(env.DB),settings(),{analyze:analyzeWithDeepSeek,dailyLimit:personalDailyLimit(identity),budget:new DailyUsageBudget(env.DB,configuredGlobalLimit(env.GLOBAL_DAILY_ANALYSIS_LIMIT))});
}
function failure(cause:unknown){
  if(cause instanceof AppError)return json({error:cause.message,code:cause.code},cause.status);
  console.error('workspace request failed',cause instanceof Error?cause.name:'unknown');
  return json({error:'研究空间暂时不可用，请稍后重试',code:'INTERNAL'},500);
}
export async function GET(request:Request){
  try {
    if(new URL(request.url).pathname!=='/api/workspace')throw new AppError('找不到接口','NOT_FOUND',404);
    const user=await getChatGPTUser();const config=settings();
    const identity=await resolveWorkspaceIdentity(request,user,env.GUEST_SESSION_SECRET,true);
    return json({state:await service(identity).workspace(identity.ownerId),configured:!!config.key?.trim(),model:config.model,authenticated:true,identityKind:identity.identityKind,dailyLimit:personalDailyLimit(identity),globalDailyLimit:configuredGlobalLimit(env.GLOBAL_DAILY_ANALYSIS_LIMIT)},200,identity.cookie);
  } catch(cause){return failure(cause);}
}
export async function POST(request:Request){
  try {
    const user=await getChatGPTUser();
    const identity=await resolveWorkspaceIdentity(request,user,env.GUEST_SESSION_SECRET,false);
    const input=await readMutationBody(request);const workspace=service(identity);const path=new URL(request.url).pathname;
    switch(path){
      case '/api/materials':return json(await workspace.importMaterial(identity.ownerId,input));
      case '/api/analyze':return json(await workspace.analyze(identity.ownerId,input.materialId));
      case '/api/resolve':return json(await workspace.resolve(identity.ownerId,input.materialId,input.eventId));
      case '/api/expire':return json(await workspace.expire(identity.ownerId));
      case '/api/notifications/read':return json(await workspace.readNotifications(identity.ownerId,input.id));
      case '/api/seed':return json(await workspace.seed(identity.ownerId));
      default:throw new AppError('找不到接口','NOT_FOUND',404);
    }
  } catch(cause){return failure(cause);}
}
