CREATE TABLE `usage_budgets` (
	`day` text PRIMARY KEY NOT NULL,
	`count` integer NOT NULL
);
