# 知序 投资事件证据台

一个以证据为中心的A股事件研究工具。面向跟踪少量公司的个人研究者，把公开材料整理为可追溯的事件、状态与版本。第一版聚焦并购重组，同时保留利润分配等独立事项，防止因“同公司、同日”错误归并。

演示站：https://event-evidence-atlas-ly-1030.yao074015.chatgpt.site

源码仓库：https://github.com/yling110500/zhixu-event-atlas

演示站面向评审公开访问；游客可直接开始研究，无需ChatGPT账号。GitHub保存完整源码；真实模型与数据库运行在服务端，不能把本项目直接当作纯静态GitHub Pages部署。

## 核心工作流

1. 浏览明确标注“人工核验”的真实历史案例，回看筹划、预案、终止三个阶段。
2. 打开“我的研究”，向空白空间载入案例起点，或直接导入新的材料正文、标题、披露日期与来源链接。
3. 服务端调用DeepSeek，抽取事件、参与公司、陈述类型和引用，判断是否归入已有事件。
4. 程序验证结构、引用、代码和日期；明确更新生成新版本，归并或时间顺序不确定的结果等待人工确认。
5. 在时间线、证据和版本之间定位依据；查看状态变化提醒、调用记录与失败重试。

材料导入支持粘贴文本或TXT/JSON文件。来源链接用于人工核验，不自动下载链接。JSON字段见`examples/material.json`。PDF上传解析与全网自动监控未实现。

## AI的角色与边界

AI承担语义抽取、同一事件候选判断、事实/观点/推测/传闻分类和证据关系分析。程序承担格式与引用检查、时间排序、版本保存、权限与并发控制。系统提示词位于`lib/provider.ts`，提示词版本为`event-evidence-1.1`。

真实分析仅调用`https://api.deepseek.com/chat/completions`，默认模型`deepseek-flash`，可通过服务端配置修改。使用结构化JSON，默认关闭思考模式以控制耗时；“真实调用”指模型确实处理输入，并不以展示内部推理作为证明。

引用校验验证的是引用确实存在于输入材料中，不证明其陈述一定正确，也不能保证模型摘要与引用在语义上完全一致。用户标注的来源类型不等于来源身份已验证。重要结论仍需人工对照原始披露。资料中的指令被视为数据，模型没有执行代码或自行联网工具。系统不提供买卖建议、目标价或收益预测。

## 数据与时间

真实历史案例来自四份公开官方文件，完整核验记录在`docs/source-research.md`。为控制复用范围，只展示必要短引、人工转述摘要、原件链接和页码。历史案例为人工核验内容，模型调用记录为空，不能冒充AI结果；真实模型处理这些摘要时同样需要标明摘要的转述性质。

发生时间、披露时间、抓取时间与结论更新时间分别保存；另记录人工导入时间。未知值为`null`，人工导入的抓取时间为空。日期只精确到天时不补造时分秒；同一天无法排序的结论变化进入待确认。旧披露不会覆盖较新结论。明确有效期的陈述在用户点击“检查时效”时检查，普通历史事实不会自动失效。

更正、否认与终止分别处理；终止是状态推进，不能把曾经筹划的历史改成虚假。更新保留不可变版本；矛盾材料保留双边依据并提示待核实。

## 源码交付

GitHub仓库提供`zhixu-source.zip`完整目录和`zhixu-source.bundle`可恢复的Git历史。连接工具缺少写入权限，故通过已登录网页上传源码包。下载ZIP解压即可运行；如需Git工作区，可执行`git clone zhixu-source.bundle zhixu-event-atlas`。源码包不含真实密钥、node_modules或用户资料。

## 本地运行

需要Node.js 22.13以上（测试使用24）及pnpm。使用锁文件安装：

```sh
pnpm install --frozen-lockfile
cp .env.example .dev.vars
```

在`.dev.vars`中填写`DEEPSEEK_API_KEY`，可选`DEEPSEEK_MODEL`。另用安全随机生成器产生至少32字符的`GUEST_SESSION_SECRET`，设置`GLOBAL_DAILY_ANALYSIS_LIMIT=50`。真实密钥不得放进源码、聊天截图、演示视频或提交包。

```sh
pnpm build
node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0000_lazy_baron_zemo.sql
node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0001_small_secret_warriors.sql
pnpm dev
```

首次启动时按顺序各执行一次上述SQL；已有本地库只执行尚未应用的文件，不要重复运行同一DDL。打开开发服务器显示的本机地址，点击“我的研究”即可开始；不要求登录。已有平台账号身份仍受兼容支持。修改`.dev.vars`后重启开发服务。

```sh
pnpm test
pnpm typecheck
pnpm build
```

若遇到TypeScript旧增量缓存，可执行`node node_modules/typescript/bin/tsc --noEmit --incremental false`。网络慢时可调整项目内`pnpm-workspace.yaml`的下载超时；不需要修改系统网络设置。

## 托管与权限

项目提供Sites托管配置，使用Vinext/Cloudflare Worker与D1。`.openai/hosting.json`包含当前项目标识与DB绑定；迁移为结构DDL，样本通过应用主动载入。托管平台密钥与本地`.dev.vars`独立配置。

演示站按用户授权公开访问。游客打开页面即获服务端签名的随机会话，Cookie为HttpOnly、SameSite=Lax、HTTPS下Secure；签名包含7天有效期。浏览器只持有会话凭证，材料、事件、版本、提醒和运行记录保存在服务端数据库。不同会话隔离，禁止客户端指定任意空间ID。已有平台登录用户继续使用原账户空间，但评审不需要登录。

游客空间与当前浏览器的Cookie绑定；换浏览器、清除Cookie、会话过期或轮换签名密钥后不能自动找回。当前无跨设备同步、找回或自助删除功能，不能把此演示空间当作长期资料仓库。Cookie过期不等于服务端记录已自动删除。

写操作要求同源JSON，单个请求上限80KB，正文上限20,000字符，每空间50份材料，同一空间一次一个分析。游客每个会话每天最多5次分析，已有平台账户每天20次；全站每天默认最多50次，以亚洲上海日期计数，在模型调用前原子占用额度，失败也计入。全站限制由`GLOBAL_DAILY_ANALYSIS_LIMIT`设置，防止新建游客会话绕过个人限额；它是次数上限，并非按金额结算的费用控制。

数据库写入采用版本比较避免并发丢失；模型运行期间目标事件变化时，新结果进入待确认。失败保留材料和旧结论。模型密钥和游客签名密钥分别配置，均不进入客户端与源码。

## 验证与交付

- `tests/`：引用、时间、事件归并、失效、错误、存储并发、身份边界、请求大小与调用额度测试。
- `docs/validation.md`：实测项目、结果和未覆盖范围。
- `docs/ai-record.md`：AI开发使用、提示词、真实接口验证和人工核验记录。
- `docs/demo-script.md`：约105秒演示脚本。
- `docs/source-research.md`：真实样本出处。

目前范围是可操作的有限资料研究工具，不是全市场实时情报服务。无自动采集、定时后台通知、邮件/短信、PDF解析、行情因果验证或自动投资决策。新闻全文授权不包含在本项目中。
