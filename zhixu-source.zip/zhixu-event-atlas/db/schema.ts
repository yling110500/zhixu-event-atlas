import { integer, sqliteTable, text } from 'drizzle-orm/sqlite-core';

export const workspaces=sqliteTable('workspaces',{
  owner:text('owner').primaryKey(),
  data:text('data').notNull(),
  revision:integer('revision').notNull(),
});

export const usageBudgets=sqliteTable('usage_budgets',{
  day:text('day').primaryKey(),
  count:integer('count').notNull(),
});
