declare namespace Cloudflare {
  interface Env {
    DB?: D1Database;
    BUCKET?: R2Bucket;
    DEEPSEEK_API_KEY?: string;
    DEEPSEEK_MODEL?: string;
    GUEST_SESSION_SECRET?: string;
    GLOBAL_DAILY_ANALYSIS_LIMIT?: string;
  }
}
