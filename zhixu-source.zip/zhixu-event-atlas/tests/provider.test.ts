import test from 'node:test';
import assert from 'node:assert/strict';
import { analyzeWithDeepSeek, PROMPT_VERSION } from '../lib/provider.ts';
import { baselineState } from '../lib/fixtures.ts';
import type { Material } from '../lib/types.ts';
const m:Material={id:'m-test',title:'海光信息终止重组',text:'海光信息（688041）于2025年12月9日审议终止重组。公司决定终止本次交易事项。',sourceUrl:'https://example.com/announcement.pdf',sourceKind:'official',publishedAt:'2025-12-10',occurredAt:null,ingestedAt:'2026-10-30T02:00:00Z',fetchedAt:null,origin:'user',status:'pending',eventId:null,error:null,fingerprint:'test'};
const output={title:'海光信息终止重组',category:'并购重组',companies:[{name:'海光信息',code:'688041'}],occurredAt:'2025-12-09',status:'terminated',summary:'公司决定终止本次交易事项。',claims:[{text:'已决定终止交易',kind:'fact',quote:'决定终止本次交易事项',materialId:m.id,validUntil:null}],relation:'initial',suggestedEventId:null,match:'new',rationale:'首次导入的明确终止公告'};
const wire=(content:string|null,finish_reason='stop')=>new Response(JSON.stringify({choices:[{finish_reason,message:{content}}],usage:{prompt_tokens:100,completion_tokens:50,total_tokens:150}}));
test('missing key rejects before any network call',async()=>{
 let called=false;await assert.rejects(()=>analyzeWithDeepSeek(m,[],{},async()=>{called=true;return wire('');}),/密钥/);assert.equal(called,false);
});
test('validated output records model, usage and exact citations',async()=>{
 const result=await analyzeWithDeepSeek(m,[],{key:'unit-test-only',model:'deepseek-flash'},async(url,init)=>{
   assert.equal(String(url),'https://api.deepseek.com/chat/completions');
   const body=JSON.parse(String(init?.body));assert.equal(body.response_format.type,'json_object');
   assert.ok(body.messages[1].content.includes(m.text));
   return wire(JSON.stringify(output));
 });
 assert.equal(result.analysis.status,'terminated');assert.equal(result.analysis.claims[0].materialId,m.id);assert.equal(result.run.usage?.total_tokens,150);assert.equal(result.run.status,'success');
});
test('authentication and quota errors never echo provider body or key',async()=>{
 await assert.rejects(()=>analyzeWithDeepSeek(m,[],{key:'secret-value'},async()=>new Response('secret-value',{status:401})),e=>e instanceof Error&&/密钥/.test(e.message)&&!e.message.includes('secret-value'));
 await assert.rejects(()=>analyzeWithDeepSeek(m,[],{key:'x'},async()=>new Response('quota',{status:429})),/额度|频率/);
});
test('empty, truncated and malformed JSON never become conclusions',async()=>{
 for(const response of [wire(null),wire('{broken'),wire(JSON.stringify(output),'length')]){
   await assert.rejects(()=>analyzeWithDeepSeek(m,[],{key:'x'},async()=>response),/为空|格式|截断/);
 }
});
test('hallucinated evidence fails before any validated result is returned',async()=>{
 const invalid={...output,claims:[{...output.claims[0],quote:'已经完成资产交割'}]};
 await assert.rejects(()=>analyzeWithDeepSeek(m,[],{key:'x'},async()=>wire(JSON.stringify(invalid))),/引用/);
});
test('request timeout aborts provider and returns a retryable failure',async()=>{
 await assert.rejects(()=>analyzeWithDeepSeek(m,[],{key:'x'},async(_url,init)=>new Promise((_resolve,reject)=>{
   init!.signal!.addEventListener('abort',()=>reject(new DOMException('Aborted','AbortError')),{once:true});
 }),10),/超时/);
});

test('candidate company codes are limited to independent codes in the current material title or text',async()=>{
 const candidates=baselineState().events;const original=structuredClone(candidates);
 const scenarios=[
   {title:'海光信息终止重组',text:m.text.replace('（688041）',''),expected:''},
   {title:'海光信息（688041）终止重组',text:m.text.replace('（688041）',''),expected:'688041'},
   {title:'海光信息终止重组',text:m.text,expected:'688041'},
   {title:'海光信息终止重组',text:m.text.replace('（688041）','（流水号16880410）'),expected:''},
 ];
 for(const scenario of scenarios){
   const material={...m,...scenario,sourceUrl:'https://example.com/688041/announcement.pdf'};
   let body='';
   const result=await analyzeWithDeepSeek(material,candidates,{key:'test-only'},async(_url,init)=>{
     body=String(init?.body);
     return wire(JSON.stringify({...output,companies:[{name:'海光信息',code:scenario.expected}]}));
   });
   const requestBody=JSON.parse(body);const input=JSON.parse(requestBody.messages[1].content);
   assert.equal(input.candidates[0].companies[0].code,scenario.expected);
   assert.equal(input.candidates[0].companies[1].code,'');
   assert.match(requestBody.messages[0].content,/只能来自当前 material.title 和 material.text/);
   assert.match(requestBody.messages[0].content,/不得从 candidates/);
   assert.equal(result.run.promptVersion,'event-evidence-1.1');
 }
 assert.deepEqual(candidates,original);assert.equal(PROMPT_VERSION,'event-evidence-1.1');
});
test('candidate knowledge still cannot authorize an unsupported company code in provider output',async()=>{
 const material={...m,text:m.text.replace('（688041）','')};
 await assert.rejects(()=>analyzeWithDeepSeek(material,baselineState().events,{key:'test-only'},async()=>wire(JSON.stringify(output))),/公司代码无法在输入材料中核验/);
});
