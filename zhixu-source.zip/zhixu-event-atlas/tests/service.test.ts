import test from 'node:test';
import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { WorkspaceRepository } from '../lib/repository.ts';
import { WorkspaceService, readMutationBody } from '../lib/service.ts';
import type { Analyzer } from '../lib/service.ts';
import { DailyUsageBudget } from '../lib/budget.ts';
import type { UsageBudget } from '../lib/budget.ts';
import { AppError } from '../lib/domain.ts';
import { personalDailyLimit } from '../lib/identity.ts';
import { sampleMaterials } from '../lib/fixtures.ts';
import type { Analysis, Material, RunRecord } from '../lib/types.ts';
function setup(key:string|undefined='server-secret',analyze?:Analyzer,now=()=> '2026-10-30T02:00:00Z',options:{dailyLimit?:number;budget?:UsageBudget}={}) {
 const sql=new DatabaseSync(':memory:');sql.exec('CREATE TABLE workspaces (owner TEXT PRIMARY KEY, data TEXT NOT NULL, revision INTEGER NOT NULL); CREATE TABLE usage_budgets (day TEXT PRIMARY KEY,count INTEGER NOT NULL)');
 const db={prepare(q:string){return {bind(...v:unknown[]){return {async first(){return sql.prepare(q).get(...v as (string|number|null)[])??null;},async run(){return {meta:{changes:Number(sql.prepare(q).run(...v as (string|number|null)[]).changes)}};}};}};}};
 const repo=new WorkspaceRepository(db);const service=new WorkspaceService(repo,{key,model:'deepseek-flash'},{analyze:analyze??success,now,...options});return {repo,service,db,sql};
}
function success(material:Material):Promise<{analysis:Analysis;run:RunRecord}> {
 return Promise.resolve({analysis:{title:'海光信息拟换股吸收合并',category:'并购重组',companies:[{name:'海光信息',code:''}],occurredAt:null,status:'planning',summary:'海光信息筹划换股吸收合并事项。',claims:[{id:'claim',text:'签署意向协议',kind:'fact',quote:'吸收合并意向协议',materialId:material.id,validUntil:null}],relation:'initial',suggestedEventId:null,match:'new',rationale:'材料明确披露筹划事项'},run:{id:'run-provider',materialId:material.id,model:'deepseek-flash',promptVersion:'test',createdAt:'2026-10-30T02:00:00Z',durationMs:1,status:'success',error:null,usage:null}});
}
test('missing credentials refuse analysis without any persistent change',async()=>{
 const {repo,service}=setup('');const imported=await service.importMaterial('a',sampleMaterials[0]);const before=await repo.read('a');
 await assert.rejects(service.analyze('a',imported.material.id),{code:'NOT_CONFIGURED',status:503});assert.deepEqual(await repo.read('a'),before);
});
test('duplicate imports and already analyzed documents are idempotent',async()=>{
 let calls=0;const {service}=setup('secret',m=>{calls++;return success(m);});
 const first=await service.importMaterial('a',sampleMaterials[0]);const second=await service.importMaterial('a',sampleMaterials[0]);assert.equal(second.duplicate,true);assert.equal(second.material.id,first.material.id);
 const result=await service.analyze('a',first.material.id);assert.equal(result.state.events.length,1);
 await service.analyze('a',first.material.id);assert.equal(calls,1);
});
test('model failure preserves imported text and historical versions, records failure, then permits retry',async()=>{
 let failed=true;const {repo,service}=setup('secret',m=>{if(failed)throw new AppError('模型服务暂时不可用','MODEL_HTTP',502);return success(m);});
 await service.seed('a');const historical=await repo.read('a');const imported=await service.importMaterial('a',{...sampleMaterials[0],text:sampleMaterials[0].text+' 新补充内容'});
 await assert.rejects(service.analyze('a',imported.material.id),{code:'MODEL_HTTP'});
 const state=(await repo.read('a')).state;assert.deepEqual(state.events,historical.state.events);assert.equal(state.materials.at(-1)?.text,imported.material.text);assert.equal(state.materials.at(-1)?.status,'failed');assert.equal(state.runs.at(-1)?.status,'failed');assert.equal(state.activeRun,null);
 failed=false;assert.equal((await service.analyze('a',imported.material.id)).state.materials.at(-1)?.status,'analyzed');
});
test('analysis commits against current state and preserves imports and notification reads while provider runs',async()=>{
 let release!:()=>void;let entered!:()=>void;const started=new Promise<void>(r=>entered=r);
 const {repo,service}=setup('secret',m=>{entered();return new Promise(r=>{release=()=>r(success(m));});});
 const first=await service.importMaterial('a',sampleMaterials[0]);await repo.update('a',s=>({...s,notifications:[{id:'notice',eventId:'old',title:'既有提醒',body:'既有结论已更新',createdAt:'2026-10-30T01:00:00Z',read:false}]}));const task=service.analyze('a',first.material.id);await started;
 await assert.rejects(service.analyze('a',first.material.id),{code:'ANALYSIS_BUSY'});
 const other=await service.importMaterial('a',sampleMaterials[3]);await service.readNotifications('a');release();await task;
 const state=(await repo.read('a')).state;assert.equal(state.materials.length,2);assert.ok(state.materials.some(m=>m.id===other.material.id));assert.equal(state.events.length,1);assert.equal(state.usage.count,1);assert.equal(state.notifications[0].read,true);
});
test('account daily budget uses Shanghai date and blocks the twenty first analysis before provider call',async()=>{
 let calls=0;const {repo,service}=setup('secret',m=>{calls++;return success(m);},()=> '2026-10-30T18:00:00Z',{dailyLimit:personalDailyLimit({ownerId:'a',identityKind:'account'})});
 const imported=await service.importMaterial('a',sampleMaterials[0]);await repo.update('a',s=>({...s,usage:{day:'2026-10-31',count:19}}));
 await service.analyze('a',imported.material.id);assert.equal(calls,1);assert.equal((await repo.read('a')).state.usage.count,20);
 const extra=await service.importMaterial('a',{...sampleMaterials[0],text:sampleMaterials[0].text+' 第二十一份补充材料'});
 await assert.rejects(service.analyze('a',extra.material.id),{code:'DAILY_LIMIT'});assert.equal(calls,1);
 await repo.update('a',s=>({...s,usage:{day:'2026-10-30',count:20}}));await service.analyze('a',extra.material.id);assert.equal(calls,2);assert.deepEqual((await repo.read('a')).state.usage,{day:'2026-10-31',count:1});
});
test('expired reservation permits retry and late old results cannot clear a new reservation',async()=>{
 let firstRelease!:()=>void;let entered!:()=>void;const started=new Promise<void>(r=>entered=r);let call=0;let now='2026-10-30T02:00:00Z';
 const {repo,service}=setup('secret',m=>{call++;if(call===1){entered();return new Promise(r=>firstRelease=()=>r(success(m)));}return success(m);},()=>now);
 const a=await service.importMaterial('a',sampleMaterials[0]);const old=service.analyze('a',a.material.id);await started;now='2026-10-30T02:03:00Z';await service.analyze('a',a.material.id);firstRelease();
 await assert.rejects(old,{code:'STALE_RUN'});const state=(await repo.read('a')).state;assert.equal(state.events.length,1);assert.equal(state.materials[0].status,'analyzed');assert.equal(state.runs.filter(r=>r.status==='success').length,1);
});

test('review confirmation uses stored evidence, creates separate event, and preserves a different active call',async()=>{
 const {repo,service}=setup('secret',async m=>{const result=await success(m);result.analysis.match='review';result.analysis.suggestedEventId='event-merger';return result;});
 await service.seed('a');const imported=await service.importMaterial('a',{...sampleMaterials[0],text:sampleMaterials[0].text+' 需要人工复核'});
 const review=await service.analyze('a',imported.material.id);assert.equal(review.state.materials.at(-1)?.status,'review');assert.equal(review.state.events.length,1);
 const reservation={id:'another',startedAt:'2026-10-30T02:00:00Z',materialId:'different'};await repo.update('a',s=>({...s,activeRun:reservation}));
 const result=await service.resolve('a',imported.material.id,null);assert.equal(result.state.events.length,2);assert.equal(result.state.materials.at(-1)?.status,'analyzed');assert.deepEqual(result.state.activeRun,reservation);
 assert.equal((await service.resolve('a',imported.material.id,null)).state.events.length,2);
 await assert.rejects(service.seed('a'),{code:'NOT_EMPTY'});
});
test('mutations require exact same origin, JSON objects, and an 80 KB streamed limit',async()=>{
 const req=(body:string,headers:Record<string,string>={})=>new Request('https://atlas.example/api/materials',{method:'POST',body,headers:{origin:'https://atlas.example','content-type':'application/json',...headers}});
 assert.deepEqual(await readMutationBody(req('{"ok":true}')),{ok:true});
 await assert.rejects(readMutationBody(req('{}',{origin:'https://other.example'})),{status:403});
 await assert.rejects(readMutationBody(req('{}',{origin:''})),{status:403});
 await assert.rejects(readMutationBody(req('{}',{'content-type':'text/plain'})),{status:415});
 await assert.rejects(readMutationBody(req('[]')),{status:400});
 await assert.rejects(readMutationBody(req('{')),{status:400});
 await assert.rejects(readMutationBody(req(JSON.stringify({text:'a'.repeat(82_000)}))),{status:413});
});

test('a delayed result becomes review when its target version changes during analysis',async()=>{
 let release!:()=>void;let entered!:()=>void;const started=new Promise<void>(r=>entered=r);
 const {repo,service}=setup('secret',async material=>{
   const result=await success(material);
   result.analysis.suggestedEventId='event-merger';result.analysis.relation='progresses';
   if(material.title==='终止重组确认材料'){
     result.analysis.status='terminated';result.analysis.summary='董事会决定终止本次交易事项。';result.analysis.match='review';
     result.analysis.claims=[{id:'termination',text:'董事会决定终止交易',kind:'fact',quote:'决定终止本次交易事项',materialId:material.id,validUntil:null}];
     return result;
   }
   result.analysis.status='progress';result.analysis.summary='海光信息披露该合并事项仍在推进。';result.analysis.match='high';
   entered();return new Promise(resolve=>{release=()=>resolve(result);});
 });
 await service.seed('a');
 const termination=await service.importMaterial('a',{...sampleMaterials[2],title:'终止重组确认材料',publishedAt:'2025-12-10'});
 await service.analyze('a',termination.material.id);
 const progress=await service.importMaterial('a',{...sampleMaterials[0],text:sampleMaterials[0].text+' 海光信息披露该合并事项仍在推进。',publishedAt:'2025-12-11'});
 const delayed=service.analyze('a',progress.material.id);await started;
 const confirmed=await service.resolve('a',termination.material.id,'event-merger');
 const target=confirmed.state.events.find(event=>event.id==='event-merger')!;
 assert.equal(target.status,'terminated');const confirmedVersionId=target.versions.at(-1)!.id;
 release();await delayed;
 const state=(await repo.read('a')).state;const latest=state.events.find(event=>event.id==='event-merger')!;
 assert.equal(latest.status,'terminated');assert.equal(latest.versions.at(-1)!.id,confirmedVersionId);
 const material=state.materials.find(m=>m.id===progress.material.id)!;
 assert.equal(material.status,'review');assert.equal(material.proposedAnalysis?.match,'review');assert.match(material.proposedAnalysis!.rationale,/版本.*变化/);
 assert.equal(state.runs.at(-1)?.status,'review');assert.equal(state.activeRun,null);
});

test('unrelated imports and notice reads do not downgrade a result for an unchanged target version',async()=>{
 let release!:()=>void;let entered!:()=>void;const started=new Promise<void>(resolve=>entered=resolve);
 const {repo,service}=setup('secret',async material=>{
   const result=await success(material);result.analysis.suggestedEventId='event-merger';result.analysis.match='high';result.analysis.status='progress';result.analysis.relation='supports';
   entered();return new Promise(resolve=>{release=()=>resolve(result);});
 });
 await service.seed('a');
 const imported=await service.importMaterial('a',{...sampleMaterials[0],text:sampleMaterials[0].text+' 海光信息披露合并事项仍在推进。',publishedAt:'2025-12-11'});
 await repo.update('a',state=>({...state,notifications:[{id:'notice',eventId:'event-merger',title:'历史提醒',body:'等待阅读',createdAt:'2025-06-10T00:00:00Z',read:false}]}));
 const analyzing=service.analyze('a',imported.material.id);await started;
 const other=await service.importMaterial('a',sampleMaterials[3]);await service.readNotifications('a','notice');release();
 const {state}=await analyzing;
 assert.equal(state.materials.find(m=>m.id===imported.material.id)?.status,'analyzed');assert.ok(state.materials.some(m=>m.id===other.material.id));
 assert.equal(state.notifications.find(n=>n.id==='notice')?.read,true);assert.equal(state.events.length,1);assert.equal(state.runs.at(-1)?.status,'success');
});

test('guest can finish ten analyses but the eleventh never calls the provider or changes saved state',async()=>{
 let calls=0;const identity={ownerId:'guest:one',identityKind:'guest'} as const;
 const {repo,service}=setup('secret',material=>{calls++;return success(material);},()=> '2026-10-30T18:00:00Z',{dailyLimit:personalDailyLimit(identity)});
 for(let i=0;i<10;i++){
  const imported=await service.importMaterial(identity.ownerId,{...sampleMaterials[0],text:sampleMaterials[0].text+` 第${i+1}份独立补充材料`});
  const {state}=await service.analyze(identity.ownerId,imported.material.id);
  assert.equal(state.materials.find(material=>material.id===imported.material.id)?.status,'analyzed');
 }
 assert.equal(calls,10);
 const extra=await service.importMaterial(identity.ownerId,{...sampleMaterials[0],text:sampleMaterials[0].text+' 第十一份待分析材料'});
 const before=await repo.read(identity.ownerId);
 assert.deepEqual(before.state.usage,{day:'2026-10-31',count:10});assert.equal(before.state.runs.length,10);
 await assert.rejects(service.analyze(identity.ownerId,extra.material.id),{code:'DAILY_LIMIT',status:429});
 assert.equal(calls,10);assert.deepEqual(await repo.read(identity.ownerId),before);
});
test('guest quota is ten attempts per Shanghai day including provider failures',async()=>{
 let calls=0;const {repo,service}=setup('secret',()=>{calls++;throw new AppError('暂时失败','MODEL_HTTP',502);},()=> '2026-10-30T18:00:00Z',{dailyLimit:personalDailyLimit({ownerId:'guest:one',identityKind:'guest'})});
 const material=await service.importMaterial('guest:one',sampleMaterials[0]);
 for(let i=0;i<10;i++)await assert.rejects(service.analyze('guest:one',material.material.id),{code:'MODEL_HTTP'});
 await assert.rejects(service.analyze('guest:one',material.material.id),{code:'DAILY_LIMIT'});assert.equal(calls,10);
 const state=(await repo.read('guest:one')).state;assert.deepEqual(state.usage,{day:'2026-10-31',count:10});assert.equal(state.runs.length,10);
});
test('concurrent workspace analyses cannot exceed the real SQL global budget or call provider after quota denial',async()=>{
 let calls=0;const {repo,db}=setup();const service=new WorkspaceService(repo,{key:'secret'},{analyze:material=>{calls++;return success(material);},now:()=> '2026-10-30T02:00:00Z',budget:new DailyUsageBudget(db,3)});
 const materials=await Promise.all(Array.from({length:12},(_,i)=>service.importMaterial(`guest:${i}`,sampleMaterials[0])));
 const results=await Promise.allSettled(materials.map((result,i)=>service.analyze(`guest:${i}`,result.material.id)));
 assert.equal(results.filter(result=>result.status==='fulfilled').length,3);assert.equal(calls,3);
 for(const result of results)if(result.status==='rejected')assert.equal(result.reason.code,'GLOBAL_DAILY_LIMIT');
 const states=await Promise.all(materials.map((_,i)=>service.workspace(`guest:${i}`)));
 assert.equal(states.reduce((sum,state)=>sum+state.usage.count,0),3);assert.ok(states.every(state=>state.activeRun===null));
});
test('provider failures consume global attempts and exhausted budget preserves imported evidence without another model run',async()=>{
 let calls=0;const {repo,db,sql}=setup();const service=new WorkspaceService(repo,{key:'secret'},{analyze:material=>{calls++;if(calls===1)throw new AppError('暂时失败','MODEL_HTTP',502);return success(material);},now:()=> '2026-10-30T02:00:00Z',budget:new DailyUsageBudget(db,2)});
 const first=await service.importMaterial('guest:a',sampleMaterials[0]);await assert.rejects(service.analyze('guest:a',first.material.id),{code:'MODEL_HTTP'});
 await service.analyze('guest:a',first.material.id);
 const second=await service.importMaterial('guest:a',{...sampleMaterials[0],text:sampleMaterials[0].text+' 补充待处理证据'});
 await assert.rejects(service.analyze('guest:a',second.material.id),{code:'GLOBAL_DAILY_LIMIT'});
 const state=await service.workspace('guest:a');assert.equal(calls,2);assert.equal(state.usage.count,2);assert.equal(state.runs.length,2);assert.equal(state.materials.at(-1)?.text,second.material.text);
 assert.equal(sql.prepare('SELECT count FROM usage_budgets').get()?.count,2);
});
