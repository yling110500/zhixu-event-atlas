import assert from 'node:assert/strict';
import test from 'node:test';
import { baselineState, demoState, sampleMaterials } from '../lib/fixtures.ts';

test('curated history keeps termination and dividend as separate events', () => {
  assert.deepEqual(demoState.materials.map(m => m.id), ['mat-plan', 'mat-preplan', 'mat-terminate', 'mat-dividend']);
  const merger = demoState.events.find(e => e.id === 'event-merger')!;
  const dividend = demoState.events.find(e => e.id === 'event-dividend')!;
  assert.deepEqual(merger.versions.map(v => v.status), ['planning', 'progress', 'terminated']);
  assert.equal(merger.status, 'terminated');
  assert.deepEqual(dividend.materialIds, ['mat-dividend']);
  assert.equal(dividend.status, 'progress');
  assert.equal(merger.materialIds.includes('mat-dividend'), false);
});

test('historical sources preserve dates and honest manual provenance', () => {
  assert.equal(sampleMaterials.length, 4);
  assert.deepEqual(demoState.runs, []);
  assert.deepEqual(demoState.materials.map(m => m.occurredAt), ['2025-05-25', '2025-06-06', '2025-12-09', '2025-12-09']);
  assert.deepEqual(demoState.materials.map(m => m.publishedAt), ['2025-05-26', '2025-06-10', '2025-12-10', '2025-12-10']);
  for (const material of demoState.materials) {
    assert.equal(material.origin, 'historical');
    assert.equal(material.ingestedAt, '2026-10-30T02:00:00Z');
    assert.equal(material.fetchedAt, null);
    assert.match(material.text, /核验摘要，非原文全文/);
    assert.ok(material.pageHint);
    assert.match(new URL(material.sourceUrl).hostname, /^(star\.sse\.com\.cn|static\.cninfo\.com\.cn)$/);
  }
  for (const event of demoState.events) for (const version of event.versions) {
    assert.equal(version.provenance, 'manual');
    assert.equal(version.updatedAt, '2026-10-30T02:00:00Z');
    const material = demoState.materials.find(m => m.id === version.materialId)!;
    assert.equal(version.asOf, material.publishedAt);
    for (const claim of version.claims) {
      assert.ok(material.text.includes(claim.quote));
      assert.ok(claim.quote.length <= 30);
      assert.equal(claim.materialId, material.id);
    }
  }
});

test('baseline is independent and contains only the first two merger materials', () => {
  const baseline = baselineState();
  assert.deepEqual(baseline.materials.map(m => m.id), ['mat-plan', 'mat-preplan']);
  assert.equal(baseline.events.length, 1);
  assert.equal(baseline.events[0].versions.length, 2);
  assert.equal(baseline.events[0].status, 'progress');
  baseline.events[0].title = 'changed';
  assert.notEqual(baselineState().events[0].title, 'changed');
  assert.notEqual(demoState.events[0].title, 'changed');
});
