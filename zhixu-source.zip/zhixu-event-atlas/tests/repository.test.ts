import test from 'node:test';
import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { WorkspaceRepository } from '../lib/repository.ts';
import { emptyState } from '../lib/domain.ts';

function database() {
  const sql = new DatabaseSync(':memory:');
  sql.exec('CREATE TABLE workspaces (owner TEXT PRIMARY KEY, data TEXT NOT NULL, revision INTEGER NOT NULL)');
  return { prepare(query: string) { return { bind(...values: unknown[]) { return { async first() { return sql.prepare(query).get(...values as (string|number|null)[]) ?? null; }, async run() { const result=sql.prepare(query).run(...values as (string|number|null)[]); return {meta:{changes:Number(result.changes)}}; } }; } }; } };
}
test('CAS rejects a stale revision and separates account workspaces using real SQL', async () => {
  const repo=new WorkspaceRepository(database());
  const first=await repo.read('alice');
  assert.equal(first.revision,null);
  const a=emptyState();a.usage.count=1;
  assert.equal(await repo.compareAndSwap('alice',null,a),true);
  assert.equal(await repo.compareAndSwap('alice',null,emptyState()),false);
  const snapshot=await repo.read('alice');assert.equal(snapshot.revision,1);
  const b=structuredClone(snapshot.state);b.usage.count=2;
  assert.equal(await repo.compareAndSwap('alice',snapshot.revision,b),true);
  assert.equal(await repo.compareAndSwap('alice',snapshot.revision,a),false);
  assert.equal((await repo.read('alice')).state.usage.count,2);
  assert.deepEqual((await repo.read('bob')).state,emptyState());
  assert.equal(await repo.compareAndSwap('bob',null,emptyState()),true);
  assert.equal((await repo.read('alice')).state.usage.count,2);
});
test('concurrent updates retry from the latest persisted revision',async()=>{
  const repo=new WorkspaceRepository(database());
  await Promise.all(Array.from({length:5},()=>repo.update('alice',state=>({...state,usage:{...state.usage,count:state.usage.count+1}}))));
  assert.equal((await repo.read('alice')).state.usage.count,5);
});
