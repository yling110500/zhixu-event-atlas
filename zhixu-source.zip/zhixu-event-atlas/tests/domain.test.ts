import test from 'node:test';
import assert from 'node:assert/strict';
import { emptyState, validateMaterial, validateAnalysis, applyAnalysis, expireClaims, materialFingerprint, addMaterial } from '../lib/domain.ts';
import type { Analysis, Material, WorkspaceState } from '../lib/types.ts';
const at='2026-10-30T02:00:00.000Z';
const material: Material={id:'m1',title:'海光信息重组进展',text:'海光信息（688041）与中科曙光（603019）的重组尚在推进，交易尚未完成。',sourceUrl:'https://www.sse.com.cn/a.pdf',sourceKind:'official',publishedAt:'2025-06-10',occurredAt:null,ingestedAt:at,fetchedAt:null,origin:'user',status:'pending',eventId:null,error:null,fingerprint:'x'};
const analysis: Analysis={title:'海光信息拟吸收合并中科曙光',category:'并购重组',companies:[{name:'海光信息',code:'688041'},{name:'中科曙光',code:'603019'}],occurredAt:'2025-06-06',status:'progress',summary:'重组尚在推进，交易尚未完成。',claims:[{id:'c1',text:'尚未完成交易',kind:'fact',quote:'交易尚未完成',materialId:'m1',validUntil:null}],relation:'initial',suggestedEventId:null,match:'new',rationale:'首次材料'};
function initial():WorkspaceState { const s=emptyState();s.materials=[structuredClone(material)];return s; }
function progress():WorkspaceState {return applyAnalysis(initial(),'m1',analysis,null,at);}
test('unverifiable quotes cannot create a conclusion',()=>assert.throws(()=>validateAnalysis({...analysis,claims:[{...analysis.claims[0],quote:'合并已经完成'}]},material,[]),/引用/));
test('material URLs reject executable schemes and disclosure dates reject impossible dates',()=>{
 assert.throws(()=>validateMaterial({...material,sourceUrl:'javascript:alert(1)'}),/链接/);
 assert.throws(()=>validateMaterial({...material,publishedAt:'2025-02-30'}),/时间/);
});
test('model cannot invent a related ticker absent from supplied text',()=>assert.throws(()=>validateAnalysis({...analysis,companies:[{name:'虚构公司',code:'999999'}]},material,[]),/公司/));
test('same company but different category cannot silently merge',()=>{
 const s=progress();const target=s.events[0];
 const out=validateAnalysis({...analysis,category:'利润分配',match:'high',suggestedEventId:target.id},material,s.events);
 assert.equal(out.match,'review');
});
test('duplicate import ignores whitespace and causes no new material',()=>{
 const a=addMaterial(emptyState(),material,at); const b=addMaterial(a.state,{...material,text:material.text.replace('与',' 与 ')},at);
 assert.equal(b.duplicate,true);assert.equal(b.state.materials.length,1);assert.equal(materialFingerprint('A B'),materialFingerprint('AB'));
});
test('a newer termination preserves previous version and adds one notice',()=>{
 const old=progress();const before=structuredClone(old.events[0].versions[0]);
 const m={...material,id:'m2',text:'海光信息决定终止本次交易事项。',publishedAt:'2025-12-10'};old.materials.push(m);
 const next=applyAnalysis(old,'m2',{...analysis,status:'terminated',summary:'本次交易已终止。',suggestedEventId:old.events[0].id,match:'high',relation:'progresses',claims:[{...analysis.claims[0],materialId:'m2',quote:'决定终止本次交易事项'}]},null,at);
 assert.equal(next.events[0].status,'terminated');assert.deepEqual(next.events[0].versions[0],before);assert.equal(next.events[0].versions.length,2);assert.equal(next.notifications.length,1);
 assert.equal(old.events[0].versions.length,1);
});
test('an older disclosure is retained without reverting newer status',()=>{
 const s=progress();s.materials.push({...material,id:'old',publishedAt:'2025-05-26'});
 const n=applyAnalysis(s,'old',{...analysis,status:'planning',summary:'早期筹划',suggestedEventId:s.events[0].id,match:'high',claims:[{...analysis.claims[0],materialId:'old'}]},null,at);
 assert.equal(n.events[0].status,'progress');assert.equal(n.events[0].materialIds.length,2);assert.equal(n.events[0].versions.length,1);assert.equal(n.notifications.length,0);
});
test('conflicting evidence marks event uncertain rather than silently overriding',()=>{
 const s=progress();s.materials.push({...material,id:'conflict',publishedAt:'2025-12-10'});
 const n=applyAnalysis(s,'conflict',{...analysis,status:'completed',relation:'contradicts',suggestedEventId:s.events[0].id,match:'high',claims:[{...analysis.claims[0],materialId:'conflict'}]},null,at);
 assert.equal(n.events[0].status,'uncertain');assert.equal(n.events[0].needsReview,true);
 assert.ok(n.events[0].versions.at(-1)!.claims.some(c=>c.materialId==='m1'));
});
test('unknown disclosure cannot supersede a dated conclusion automatically',()=>{
 const s=progress();s.materials.push({...material,id:'unknown',publishedAt:null});
 const n=applyAnalysis(s,'unknown',{...analysis,status:'completed',suggestedEventId:s.events[0].id,match:'high',claims:[{...analysis.claims[0],materialId:'unknown'}]},null,at);
 assert.equal(n.materials.at(-1)!.status,'review');assert.equal(n.events[0].status,'progress');
});
test('expired dated claim creates one revision, leaves historic factual claim untouched',()=>{
 const s=progress();s.events[0].versions[0].claims.push({...analysis.claims[0],id:'dated',kind:'opinion',validUntil:'2025-07-01'});
 const n=expireClaims(s,at);assert.equal(n.events[0].versions.length,2);assert.equal(n.events[0].versions.at(-1)!.claims[0].expired,undefined);
 assert.equal(n.events[0].versions.at(-1)!.claims[1].expired,true);assert.equal(n.events[0].status,'progress');
 assert.equal(expireClaims(n,at).events[0].versions.length,2);
});
test('a supporting paraphrase does not create a change notification',()=>{
 const s=progress();s.materials.push({...material,id:'support',publishedAt:'2025-06-11'});
 const n=applyAnalysis(s,'support',{...analysis,summary:'仍处于重组推进阶段，尚未完成。',relation:'supports',suggestedEventId:s.events[0].id,match:'high',claims:[{...analysis.claims[0],materialId:'support'}]},null,at);
 assert.equal(n.events[0].versions.length,2);assert.equal(n.notifications.length,0);
});
test('timezone-offset disclosure ordering compares actual instants',()=>{
 const s=progress();s.events[0].versions[0].asOf='2025-06-10T10:00:00Z';s.materials[0].publishedAt='2025-06-10T10:00:00Z';s.materials.push({...material,id:'tz',publishedAt:'2025-06-10T11:00:00+08:00'});
 const n=applyAnalysis(s,'tz',{...analysis,status:'planning',summary:'仍在初步筹划',suggestedEventId:s.events[0].id,match:'high',claims:[{...analysis.claims[0],materialId:'tz'}]},null,at);
 assert.equal(n.events[0].status,'progress');assert.equal(n.events[0].versions.length,1);
});
test('same-day date-only changing conclusions require review instead of import-order overwrite',()=>{
 const s=progress();s.materials.push({...material,id:'same-day',publishedAt:'2025-06-10'});
 const n=applyAnalysis(s,'same-day',{...analysis,status:'terminated',summary:'交易终止',suggestedEventId:s.events[0].id,match:'high',claims:[{...analysis.claims[0],materialId:'same-day'}]},null,at);
 assert.equal(n.events[0].status,'progress');assert.equal(n.materials.at(-1)!.status,'review');
});
test('newer identical support advances watermark and preserves its evidence without a notification',()=>{
 const s=progress();s.materials.push({...material,id:'aug',publishedAt:'2025-08-01'});
 const n=applyAnalysis(s,'aug',{...analysis,suggestedEventId:s.events[0].id,match:'high',relation:'supports',claims:[{...analysis.claims[0],materialId:'aug'}]},null,at);
 assert.equal(n.events[0].versions.at(-1)!.asOf,'2025-08-01');assert.equal(n.events[0].versions.at(-1)!.claims[0].materialId,'aug');assert.equal(n.notifications.length,0);
 n.materials.push({...material,id:'july',publishedAt:'2025-07-01'});
 const final=applyAnalysis(n,'july',{...analysis,status:'planning',summary:'早期筹划',suggestedEventId:s.events[0].id,match:'high',claims:[{...analysis.claims[0],materialId:'july'}]},null,at);
 assert.equal(final.events[0].status,'progress');assert.equal(final.events[0].versions.at(-1)!.asOf,'2025-08-01');
});
test('contradictory new-event matching output cannot merge into an existing event',()=>{
 const s=progress();assert.throws(()=>validateAnalysis({...analysis,match:'new',suggestedEventId:s.events[0].id},material,s.events),/新事件|归并/);
});
test('version snapshots never share mutable claims with the provider output',()=>{
 const own=structuredClone(analysis);own.claims=[{...own.claims[0],validUntil:null}];const n=applyAnalysis(initial(),'m1',own,null,at);
 own.claims[0].text='被外部修改';assert.notEqual(n.events[0].versions[0].claims[0].text,'被外部修改');
});
