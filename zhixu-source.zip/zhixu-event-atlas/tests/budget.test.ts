import test from 'node:test';
import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { DailyUsageBudget, configuredGlobalLimit } from '../lib/budget.ts';
function database(){
 const sql=new DatabaseSync(':memory:');sql.exec('CREATE TABLE usage_budgets (day TEXT PRIMARY KEY,count INTEGER NOT NULL)');
 return {sql,db:{prepare(q:string){return {bind(...values:unknown[]){return {async first(){return sql.prepare(q).get(...values as (string|number|null)[])??null;},async run(){return {meta:{changes:Number(sql.prepare(q).run(...values as (string|number|null)[]).changes)}};}};}};}}};
}
test('atomic real SQLite global quota never admits more than its limit across concurrent users',async()=>{
 const {sql,db}=database();const budget=new DailyUsageBudget(db,7);
 const results=await Promise.allSettled(Array.from({length:60},()=>budget.consume('2026-10-30T18:00:00Z')));
 assert.equal(results.filter(result=>result.status==='fulfilled').length,7);
 const failed=results.filter(result=>result.status==='rejected');assert.equal(failed.length,53);
 for(const result of failed)if(result.status==='rejected')assert.equal(result.reason.code,'GLOBAL_DAILY_LIMIT');
 assert.equal(sql.prepare('SELECT count FROM usage_budgets WHERE day=?').get('2026-10-31')?.count,7);
 await budget.consume('2026-10-31T18:00:00Z');assert.equal(sql.prepare('SELECT count FROM usage_budgets WHERE day=?').get('2026-11-01')?.count,1);
});
test('global limit defaults to fifty and configuration cannot remove its finite cap',()=>{
 assert.equal(configuredGlobalLimit(undefined),50);assert.equal(configuredGlobalLimit('7'),7);
 for(const value of ['0','-1','Infinity','1001','garbage'])assert.throws(()=>configuredGlobalLimit(value),{code:'BUDGET_NOT_CONFIGURED',status:503});
});
