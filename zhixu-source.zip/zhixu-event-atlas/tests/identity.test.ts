import test from 'node:test';
import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { WorkspaceRepository } from '../lib/repository.ts';
import { emptyState } from '../lib/domain.ts';
import { resolveWorkspaceIdentity, GUEST_COOKIE_NAME } from '../lib/identity.ts';
const secret='test-only-session-secret-that-is-at-least-32-characters';
const now=Date.parse('2026-10-30T02:00:00Z');
const request=(cookie?:string,url='https://atlas.example/api/workspace')=>new Request(url,{headers:cookie?{cookie}:{}});
const cookiePair=(cookie:string)=>cookie.split(';',1)[0];
test('new guests get unique signed HttpOnly cookies and verified stable isolated owners',async()=>{
 const a=await resolveWorkspaceIdentity(request(),null,secret,true,now);
 const b=await resolveWorkspaceIdentity(request(),null,secret,true,now);
 assert.equal(a.identityKind,'guest');assert.notEqual(a.ownerId,b.ownerId);assert.match(a.ownerId,/^guest:[0-9a-f-]{36}$/);
 assert.match(a.cookie!,/HttpOnly/);assert.match(a.cookie!,/SameSite=Lax/);assert.match(a.cookie!,/Secure/);assert.match(a.cookie!,/Max-Age=604800/);assert.match(a.cookie!,/Path=\//);
 const verified=await resolveWorkspaceIdentity(request(cookiePair(a.cookie!)),null,secret,false,now+1000);
 assert.equal(verified.ownerId,a.ownerId);assert.equal(verified.cookie,undefined);
 const http=await resolveWorkspaceIdentity(request(undefined,'http://localhost/api/workspace'),null,secret,true,now);
 assert.doesNotMatch(http.cookie!,/Secure/);
});
test('guest mutation identity rejects missing, tampered, expired and differently signed cookies',async()=>{
 const guest=await resolveWorkspaceIdentity(request(),null,secret,true,now);const pair=cookiePair(guest.cookie!);
 await assert.rejects(resolveWorkspaceIdentity(request(),null,secret,false,now),{status:401});
 const [name,value]=pair.split('=');const [payload,signature]=value.split('.');
 const decoded=JSON.parse(atob(payload.replace(/-/g,'+').replace(/_/g,'/')));decoded.id=crypto.randomUUID();
 const altered=btoa(JSON.stringify(decoded)).replace(/=/g,'').replace(/\+/g,'-').replace(/\//g,'_');
 await assert.rejects(resolveWorkspaceIdentity(request(`${name}=${altered}.${signature}`),null,secret,false,now),{status:401});
 await assert.rejects(resolveWorkspaceIdentity(request(pair),null,secret,false,now+604800000),{status:401});
 await assert.rejects(resolveWorkspaceIdentity(request(pair),null,secret+'other',false,now),{status:401});
 const rotated=await resolveWorkspaceIdentity(request(`${GUEST_COOKIE_NAME}=invalid`),null,secret,true,now);assert.ok(rotated.cookie);assert.notEqual(rotated.ownerId,guest.ownerId);
});
test('account owners remain compatible and guest signing requires its own configured secret',async()=>{
 assert.deepEqual(await resolveWorkspaceIdentity(request(),{userId:'existing-account'},undefined,false,now),{ownerId:'existing-account',identityKind:'account'});
 await assert.rejects(resolveWorkspaceIdentity(request(),null,undefined,true,now),{code:'GUEST_NOT_CONFIGURED',status:503});
 await assert.rejects(resolveWorkspaceIdentity(request(),null,'too-short',true,now),{code:'GUEST_NOT_CONFIGURED',status:503});
});

test('verified guest owners persist isolated data and ignore client supplied owner hints',async()=>{
 const first=await resolveWorkspaceIdentity(request(),null,secret,true,now);
 const second=await resolveWorkspaceIdentity(request(),null,secret,true,now);
 const sql=new DatabaseSync(':memory:');sql.exec('CREATE TABLE workspaces (owner TEXT PRIMARY KEY,data TEXT NOT NULL,revision INTEGER NOT NULL)');
 const db={prepare(query:string){return {bind(...values:unknown[]){return {async first(){return sql.prepare(query).get(...values as (string|number|null)[])??null;},async run(){return {meta:{changes:Number(sql.prepare(query).run(...values as (string|number|null)[]).changes)}};}};}};}};
 const repo=new WorkspaceRepository(db);const state=emptyState();state.usage={day:'2026-10-30',count:5};
 await repo.compareAndSwap(first.ownerId,null,state);
 const hinted=new Request('https://atlas.example/api/workspace?owner=victim',{headers:{cookie:cookiePair(second.cookie!),'x-owner-id':first.ownerId}});
 const verified=await resolveWorkspaceIdentity(hinted,null,secret,false,now+1000);
 assert.equal(verified.ownerId,second.ownerId);assert.deepEqual((await repo.read(verified.ownerId)).state,emptyState());
 assert.equal((await repo.read(first.ownerId)).state.usage.count,5);
});
