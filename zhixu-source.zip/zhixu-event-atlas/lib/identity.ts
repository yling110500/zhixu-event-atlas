import { AppError } from './domain.ts';

export const GUEST_COOKIE_NAME='event_atlas_guest';
const TTL_SECONDS=7*24*60*60;
export interface WorkspaceIdentity { ownerId:string; identityKind:'account'|'guest'; cookie?:string; }
export function personalDailyLimit(identity:WorkspaceIdentity):number{return identity.identityKind==='guest'?10:20;}
interface GuestPayload {id:string;expiresAt:number;}
function encode(bytes:Uint8Array){return btoa(String.fromCharCode(...bytes)).replace(/=/g,'').replace(/\+/g,'-').replace(/\//g,'_');}
function decode(value:string):Uint8Array<ArrayBuffer> {
  if(!/^[A-Za-z0-9_-]+$/.test(value))throw new Error('Invalid token encoding');
  return Uint8Array.from(atob(value.replace(/-/g,'+').replace(/_/g,'/')),character=>character.charCodeAt(0));
}
async function signingKey(secret:string){return crypto.subtle.importKey('raw',new TextEncoder().encode(secret),{name:'HMAC',hash:'SHA-256'},false,['sign','verify']);}
function cookieValue(request:Request):string|undefined {
  return request.headers.get('cookie')?.split(';').map(part=>part.trim()).find(part=>part.startsWith(`${GUEST_COOKIE_NAME}=`))?.slice(GUEST_COOKIE_NAME.length+1);
}
async function verify(token:string|undefined,key:CryptoKey,now:number):Promise<GuestPayload|null>{
  if(!token||token.length>1024)return null;
  try {
    const parts=token.split('.');if(parts.length!==2)return null;
    const [body,signature]=parts;
    if(!await crypto.subtle.verify('HMAC',key,decode(signature),new TextEncoder().encode(body)))return null;
    const payload:unknown=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(decode(body)));
    if(!payload||typeof payload!=='object')return null;
    const value=payload as Record<string,unknown>;
    if(typeof value.id!=='string'||!/^([a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12})$/.test(value.id))return null;
    if(typeof value.expiresAt!=='number'||!Number.isSafeInteger(value.expiresAt)||value.expiresAt<=now||value.expiresAt>now+TTL_SECONDS*1000)return null;
    return {id:value.id,expiresAt:value.expiresAt};
  } catch{return null;}
}
/** Account owners retain their original keys; anonymous owners come only from verified server tokens. */
export async function resolveWorkspaceIdentity(request:Request,account:{userId:string}|null,secret:string|undefined,issueGuest:boolean,now=Date.now()):Promise<WorkspaceIdentity>{
  if(account)return {ownerId:account.userId,identityKind:'account'};
  if(!secret||secret.length<32)throw new AppError('游客研究空间尚未配置独立会话密钥，请联系管理员','GUEST_NOT_CONFIGURED',503);
  const key=await signingKey(secret);const existing=await verify(cookieValue(request),key,now);
  if(existing)return {ownerId:`guest:${existing.id}`,identityKind:'guest'};
  if(!issueGuest)throw new AppError('游客会话已失效，请刷新页面后重试','UNAUTHENTICATED',401);
  const payload:GuestPayload={id:crypto.randomUUID(),expiresAt:now+TTL_SECONDS*1000};
  const body=encode(new TextEncoder().encode(JSON.stringify(payload)));
  const signature=encode(new Uint8Array(await crypto.subtle.sign('HMAC',key,new TextEncoder().encode(body))));
  const secure=new URL(request.url).protocol==='https:'?'; Secure':'';
  const cookie=`${GUEST_COOKIE_NAME}=${body}.${signature}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${TTL_SECONDS}${secure}`;
  return {ownerId:`guest:${payload.id}`,identityKind:'guest',cookie};
}
