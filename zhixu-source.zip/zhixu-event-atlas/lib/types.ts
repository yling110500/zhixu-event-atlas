export type SourceKind = 'official' | 'media' | 'research' | 'other';
export type ClaimKind = 'fact' | 'opinion' | 'inference' | 'rumor';
export type EventStatus = 'planning' | 'progress' | 'completed' | 'terminated' | 'denied' | 'uncertain' | 'expired';
export type Relation = 'initial' | 'supports' | 'supplements' | 'contradicts' | 'corrects' | 'denies' | 'progresses';
export interface Company { name: string; code: string }
export interface MaterialInput { title: string; text: string; sourceUrl: string; sourceKind: SourceKind; publishedAt: string | null; }
export interface Material extends MaterialInput {
  id: string; fingerprint: string; occurredAt: string | null; ingestedAt: string; fetchedAt: string | null;
  origin: 'user' | 'historical'; status: 'pending' | 'analyzed' | 'review' | 'failed'; eventId: string | null; error: string | null;
  proposedAnalysis?: Analysis; pageHint?: string;
}
export interface Claim { id: string; text: string; kind: ClaimKind; quote: string; materialId: string; validUntil: string | null; expired?: boolean; }
export interface Analysis {
  title: string; category: string; companies: Company[]; occurredAt: string | null; status: EventStatus; summary: string;
  claims: Claim[]; relation: Relation; suggestedEventId: string | null; match: 'high' | 'review' | 'new'; rationale: string;
}
export interface Version {
  id: string; number: number; status: EventStatus; summary: string; claims: Claim[]; reason: string; relation: Relation;
  materialId: string; updatedAt: string; asOf: string | null; provenance: 'manual' | 'deepseek' | 'expiry';
}
export interface EventRecord {
  id: string; title: string; category: string; companies: Company[]; status: EventStatus; summary: string;
  materialIds: string[]; versions: Version[]; updatedAt: string; needsReview: boolean;
}
export interface Notice { id: string; eventId: string; title: string; body: string; createdAt: string; read: boolean; }
export interface RunRecord { id: string; materialId: string; model: string; promptVersion: string; createdAt: string; durationMs: number; status: 'success' | 'failed' | 'review'; error: string | null; usage: { prompt_tokens?: number; completion_tokens?: number; total_tokens?: number } | null; }
export interface WorkspaceState {
  schemaVersion: 1; materials: Material[]; events: EventRecord[]; notifications: Notice[]; runs: RunRecord[];
  usage: { day: string; count: number }; activeRun: { id: string; startedAt: string; materialId: string } | null;
}
export interface WorkspaceResponse { state: WorkspaceState; configured: boolean; model: string; authenticated: boolean; identityKind: 'guest' | 'account'; dailyLimit: number; globalDailyLimit: number; }
