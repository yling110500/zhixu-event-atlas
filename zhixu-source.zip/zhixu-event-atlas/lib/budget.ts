import { AppError } from './domain.ts';
import type { WorkspaceDatabase } from './repository.ts';
export function shanghaiDay(now:string):string{return new Date(new Date(now).getTime()+8*60*60*1000).toISOString().slice(0,10);}
export function configuredGlobalLimit(value:string|undefined):number {
  if(value===undefined||value.trim()==='')return 50;
  if(!/^\d{1,4}$/.test(value)||Number(value)<1||Number(value)>1000)throw new AppError('全站每日分析上限必须配置为1至1000之间的整数','BUDGET_NOT_CONFIGURED',503);
  return Number(value);
}
export interface UsageBudget {consume(now:string):Promise<void>;}
export class DailyUsageBudget implements UsageBudget {
  private db:WorkspaceDatabase;private limit:number;
  constructor(db:WorkspaceDatabase,limit=50){
    if(!Number.isInteger(limit)||limit<1||limit>1000)throw new AppError('全站分析额度配置无效','BUDGET_NOT_CONFIGURED',503);
    this.db=db;this.limit=limit;
  }
  async consume(now:string):Promise<void>{
    // A single SQLite statement admits an attempt atomically across every workspace.
    const result=await this.db.prepare('INSERT INTO usage_budgets (day, count) VALUES (?, 1) ON CONFLICT(day) DO UPDATE SET count = count + 1 WHERE count < ?').bind(shanghaiDay(now),this.limit).run();
    if(result.meta?.changes!==1)throw new AppError(`本站今天的${this.limit}次分析额度已用完，请明天再试`,'GLOBAL_DAILY_LIMIT',429);
  }
}
