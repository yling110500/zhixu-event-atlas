import { addMaterial, applyAnalysis, AppError, expireClaims, freshId, validateAnalysis } from './domain.ts';
import { baselineState } from './fixtures.ts';
import { WorkspaceRepository } from './repository.ts';
import { PROMPT_VERSION } from './provider.ts';
import { shanghaiDay } from './budget.ts';
import type { UsageBudget } from './budget.ts';
import type { Analysis, EventRecord, Material, RunRecord, WorkspaceState } from './types.ts';

export interface ModelConfig { key?:string; model?:string; }
export type Analyzer=(material:Material,candidates:EventRecord[],config:ModelConfig,fetcher?:typeof fetch,timeoutMs?:number)=>Promise<{analysis:Analysis;run:RunRecord}>;
interface ServiceDependencies { analyze:Analyzer; now?:()=>string; dailyLimit?:number; budget?:UsageBudget; }
const MODEL_TIMEOUT_MS=45_000;
function requireId(value:unknown,name='材料'):string {
  if(typeof value!=='string'||value.length<1||value.length>150)throw new AppError(`${name}编号无效`);
  return value;
}
export class WorkspaceService {
  private repo:WorkspaceRepository;private config:ModelConfig;private dependencies:ServiceDependencies;
  constructor(repo:WorkspaceRepository,config:ModelConfig,dependencies:ServiceDependencies){
    const limit=dependencies.dailyLimit??20;
    if(!Number.isInteger(limit)||limit<1||limit>20)throw new AppError('个人每日分析额度配置无效','BUDGET_NOT_CONFIGURED',503);
    this.repo=repo;this.config=config;this.dependencies=dependencies;
  }
  private now(){return this.dependencies.now?.()??new Date().toISOString();}
  async workspace(owner:string){return (await this.repo.read(owner)).state;}
  async importMaterial(owner:string,input:unknown) {
    let result!:ReturnType<typeof addMaterial>;
    const state=await this.repo.update(owner,state=>{result=addMaterial(state,input,this.now());return result.state;});
    return {state,material:result.material,duplicate:result.duplicate};
  }
  async analyze(owner:string,value:unknown):Promise<{state:WorkspaceState}> {
    const materialId=requireId(value);
    if(!this.config.key?.trim())throw new AppError('请先配置服务端 DeepSeek API Key','NOT_CONFIGURED',503);
    const reservation={id:freshId('reservation'),startedAt:this.now(),materialId};
    const state=await this.repo.update(owner,current=>{
      const material=current.materials.find(m=>m.id===materialId);
      if(!material)throw new AppError('找不到材料','NOT_FOUND',404);
      if(material.status==='analyzed'||material.status==='review')return current;
      const now=this.now();
      if(current.activeRun&&new Date(now).getTime()-new Date(current.activeRun.startedAt).getTime()<=120_000)throw new AppError('当前研究空间已有分析进行中','ANALYSIS_BUSY',409);
      const day=shanghaiDay(now);const count=current.usage.day===day?current.usage.count:0;
      const limit=this.dependencies.dailyLimit??20;
      if(count>=limit)throw new AppError(`今天的${limit}次分析额度已用完，请明天再试`,'DAILY_LIMIT',429);
      const next=structuredClone(current);next.activeRun=reservation;next.usage={day,count:count+1};
      const nextMaterial=next.materials.find(m=>m.id===materialId)!;nextMaterial.status='pending';nextMaterial.error=null;
      return next;
    });
    if(state.activeRun?.id!==reservation.id)return {state};
    const material=state.materials.find(m=>m.id===materialId)!;
    const candidateVersions=new Map(state.events.map(event=>[event.id,event.versions.at(-1)?.id??null]));
    const started=Date.now();let timer:ReturnType<typeof setTimeout>|undefined;let providerAttempted=false;
    try {
      await this.dependencies.budget?.consume(this.now());
      providerAttempted=true;
      const output=await Promise.race([
        this.dependencies.analyze(material,state.events,this.config,undefined,MODEL_TIMEOUT_MS),
        new Promise<never>((_,reject)=>{timer=setTimeout(()=>reject(new AppError('分析超时，请重试','MODEL_TIMEOUT',504)),MODEL_TIMEOUT_MS);}),
      ]);
      const analysis=validateAnalysis(output.analysis,material,state.events);
      const saved=await this.repo.update(owner,current=>{
        if(current.activeRun?.id!==reservation.id)throw new AppError('分析预约已过期，请刷新查看最新结果','STALE_RUN',409);
        // Run IDs and material association are server controlled, even with a custom provider.
        const run={...output.run,id:reservation.id,materialId,model:this.config.model??'deepseek-flash'};
        const target=analysis.suggestedEventId?current.events.find(event=>event.id===analysis.suggestedEventId):undefined;
        const targetChanged=analysis.suggestedEventId!==null&&candidateVersions.get(analysis.suggestedEventId)!==(target?.versions.at(-1)?.id??null);
        const currentAnalysis:Analysis=targetChanged
          ?{...analysis,match:'review',rationale:`分析期间目标事件的结论版本已变化，当前结果基于旧版本，需人工确认后再归并。${analysis.rationale}`.slice(0,800)}
          :analysis;
        return applyAnalysis(current,materialId,currentAnalysis,run,this.now());
      });
      return {state:saved};
    } catch(cause) {
      const error=this.safeError(cause);
      await this.repo.update(owner,current=>{
        if(current.activeRun?.id!==reservation.id)return current;
        const next=structuredClone(current);const failed=next.materials.find(m=>m.id===materialId);
        if(failed){failed.status='failed';failed.error=error.message;}
        next.activeRun=null;
        if(!providerAttempted&&next.usage.day===state.usage.day)next.usage.count=Math.max(0,next.usage.count-1);
        if(providerAttempted)next.runs.push({id:reservation.id,materialId,model:this.config.model??'deepseek-flash',promptVersion:PROMPT_VERSION,createdAt:this.now(),durationMs:Date.now()-started,status:'failed',error:error.message,usage:null});
        return next;
      });
      throw error;
    } finally {if(timer!==undefined)clearTimeout(timer);}
  }
  private safeError(cause:unknown):AppError {
    if(!(cause instanceof AppError))return new AppError('分析暂时失败，请稍后重试','ANALYSIS_FAILED',502);
    const secret=this.config.key;
    return new AppError(secret?cause.message.split(secret).join('[已隐藏]'):cause.message,cause.code,cause.status);
  }
  async resolve(owner:string,materialValue:unknown,eventValue:unknown) {
    const materialId=requireId(materialValue);const eventId=eventValue===null?null:requireId(eventValue,'事件');
    const state=await this.repo.update(owner,current=>{
      const material=current.materials.find(m=>m.id===materialId);
      if(!material)throw new AppError('找不到材料','NOT_FOUND',404);
      if(material.status==='analyzed')return current;
      if(material.status!=='review'||!material.proposedAnalysis)throw new AppError('此材料没有待确认的归并建议','NOT_REVIEW',409);
      if(eventId&&!current.events.some(e=>e.id===eventId))throw new AppError('找不到目标事件','NOT_FOUND',404);
      const analysis=validateAnalysis({...material.proposedAnalysis,suggestedEventId:eventId,match:eventId?'high':'new'},material,current.events);
      const next=applyAnalysis(current,materialId,analysis,null,this.now(),true);
      // Confirmation is independent of any other document's current provider call.
      next.activeRun=current.activeRun;return next;
    });return {state};
  }
  async expire(owner:string){return {state:await this.repo.update(owner,s=>expireClaims(s,this.now()))};}
  async readNotifications(owner:string,value?:unknown){
    const id=value===undefined?undefined:requireId(value,'提醒');
    return {state:await this.repo.update(owner,current=>({...current,notifications:current.notifications.map(n=>!id||n.id===id?{...n,read:true}:n)}))};
  }
  async seed(owner:string){return {state:await this.repo.update(owner,current=>{
    if(current.materials.length||current.events.length||current.runs.length||current.activeRun)throw new AppError('仅能向空白研究空间载入案例起点','NOT_EMPTY',409);
    return baselineState();
  })};}
}

/** Shared HTTP guard, kept independent from framework bindings for direct request tests. */
export async function readMutationBody(request:Request):Promise<Record<string,unknown>> {
  if(request.headers.get('origin')!==new URL(request.url).origin)throw new AppError('请求来源不受信任','ORIGIN',403);
  if(request.headers.get('content-type')?.split(';',1)[0].trim().toLowerCase()!=='application/json')throw new AppError('请求必须使用JSON格式','CONTENT_TYPE',415);
  const limit=80*1024;const length=request.headers.get('content-length');
  if(length&&(!/^\d+$/.test(length)||Number(length)>limit))throw new AppError('请求内容超过80KB上限','BODY_LIMIT',413);
  const reader=request.body?.getReader();
  if(!reader)throw new AppError('请求内容不能为空');
  const chunks:Uint8Array[]=[];let size=0;
  try {
    for(;;){
      const {done,value}=await reader.read();if(done)break;
      size+=value.byteLength;
      if(size>limit){await reader.cancel();throw new AppError('请求内容超过80KB上限','BODY_LIMIT',413);}
      chunks.push(value);
    }
  } finally {reader.releaseLock();}
  const bytes=new Uint8Array(size);let offset=0;for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.byteLength;}
  let data:unknown;try{data=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes));}catch{throw new AppError('JSON内容无效');}
  if(!data||typeof data!=='object'||Array.isArray(data))throw new AppError('JSON内容必须是对象');
  return data as Record<string,unknown>;
}
