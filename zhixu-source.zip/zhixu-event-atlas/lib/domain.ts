import type { Analysis, Claim, EventRecord, Material, MaterialInput, RunRecord, WorkspaceState } from './types.ts';

export class AppError extends Error {
  code: string; status: number;
  constructor(message: string, code='VALIDATION', status=400) { super(message); this.code=code; this.status=status; }
}
export const freshId = (prefix:string) => `${prefix}-${crypto.randomUUID()}`;
export function emptyState():WorkspaceState {return {schemaVersion:1,materials:[],events:[],notifications:[],runs:[],usage:{day:'',count:0},activeRun:null};}
export const normalize = (s:string) => s.normalize('NFKC').replace(/\s+/gu,'').trim();
export function materialFingerprint(text:string):string {
  let hash=14695981039346656037n;
  for (const c of normalize(text)) hash=BigInt.asUintN(64,(hash^BigInt(c.codePointAt(0)!))*1099511628211n);
  return hash.toString(16);
}
function str(value:unknown,name:string,min:number,max:number):string {
  if(typeof value!=='string'||value.trim().length<min||value.length>max) throw new AppError(`${name}应为${min}至${max}个字符`);
  return value.trim();
}
export function dateValue(value:unknown):string|null {
  if(value===null||value===undefined||value==='') return null;
  if(typeof value!=='string'||!/^\d{4}-\d{2}-\d{2}(T\d{2}:\d{2}:\d{2}(\.\d{1,3})?(Z|[+-]\d{2}:\d{2}))?$/.test(value)) throw new AppError('时间格式不正确，请使用日期或含时区的时间');
  const d=new Date(value);const day=value.slice(0,10);const cal=new Date(day+'T00:00:00Z');
  if(!Number.isFinite(+d)||cal.toISOString().slice(0,10)!==day) throw new AppError('时间包含不存在的日期');
  return value;
}
export function validateMaterial(input:unknown):MaterialInput {
  if(!input||typeof input!=='object') throw new AppError('材料格式不正确');
  const a=input as Record<string,unknown>;
  const title=str(a.title,'标题',2,160);const text=str(a.text,'正文',20,20000);
  const sourceUrl=str(a.sourceUrl,'来源链接',8,2000);
  let url:URL;try{url=new URL(sourceUrl);}catch{throw new AppError('来源链接无效');}
  if(!['https:','http:'].includes(url.protocol)||url.username||url.password) throw new AppError('来源链接仅支持无凭据的HTTP或HTTPS地址');
  if(!['official','media','research','other'].includes(String(a.sourceKind))) throw new AppError('请选择来源类别');
  return {title,text,sourceUrl,sourceKind:a.sourceKind as MaterialInput['sourceKind'],publishedAt:dateValue(a.publishedAt)};
}
export function addMaterial(state:WorkspaceState,input:unknown,now:string) {
  const data=validateMaterial(input);const fp=materialFingerprint(data.text);
  const existing=state.materials.find(m=>m.fingerprint===fp&&normalize(m.text)===normalize(data.text));
  if(existing) return {state,material:existing,duplicate:true};
  if(state.materials.length>=50) throw new AppError('当前研究空间最多保存50份材料，请导出记录后使用新空间','LIMIT',429);
  const material:Material={...data,id:freshId('mat'),fingerprint:fp,occurredAt:null,ingestedAt:now,fetchedAt:null,origin:'user',status:'pending',eventId:null,error:null};
  return {state:{...state,materials:[...state.materials,material]},material,duplicate:false};
}
const statuses=['planning','progress','completed','terminated','denied','uncertain','expired'];
const relations=['initial','supports','supplements','contradicts','corrects','denies','progresses'];
export function validateAnalysis(raw:unknown,material:Material,candidates:EventRecord[]):Analysis {
  if(!raw||typeof raw!=='object') throw new AppError('模型返回格式无效','MODEL_OUTPUT',502);
  const a=raw as Record<string,any>;
  const title=str(a.title,'事件标题',2,100);const summary=str(a.summary,'结论',4,1200);const category=str(a.category,'事件类别',2,30);
  if(!statuses.includes(a.status)||!relations.includes(a.relation)||!['high','review','new'].includes(a.match)) throw new AppError('模型状态或关系不在允许范围内','MODEL_OUTPUT',502);
  if(!Array.isArray(a.companies)||a.companies.length<1||a.companies.length>6) throw new AppError('模型公司列表无效','MODEL_OUTPUT',502);
  const companies=a.companies.map((c:any)=>{
    const name=str(c.name,'公司名称',2,50);const code=typeof c.code==='string'?c.code.trim():'';
    if(code&&!/^\d{5,6}$/.test(code)) throw new AppError('公司代码格式无效','MODEL_OUTPUT',502);
    if(!normalize(material.text).includes(normalize(name))&&!normalize(material.title).includes(normalize(name))) throw new AppError('公司名称无法在输入材料中核验','MODEL_OUTPUT',502);
    if(code&&!material.text.includes(code)&&!material.title.includes(code)) throw new AppError('公司代码无法在输入材料中核验','MODEL_OUTPUT',502);
    return {name,code};
  });
  if(!Array.isArray(a.claims)||a.claims.length<1||a.claims.length>12) throw new AppError('模型必须提供1至12条有引用的陈述','MODEL_OUTPUT',502);
  const claims:Claim[]=a.claims.map((c:any,index:number)=>{
    const text=str(c.text,'陈述',2,600);const quote=str(c.quote,'引用',4,300);
    if(c.materialId!==material.id||!normalize(material.text).includes(normalize(quote))) throw new AppError('引用未能匹配输入材料，结论未保存','INVALID_CITATION',502);
    if(!['fact','opinion','inference','rumor'].includes(c.kind)) throw new AppError('陈述类别无效','MODEL_OUTPUT',502);
    const validUntil=dateValue(c.validUntil);
    // A model-supplied expiration needs explicit source support, not a fabricated default TTL.
    if(validUntil&&!material.text.includes(validUntil.slice(0,10))&&!material.text.includes(validUntil.slice(0,10).replace(/-(\d{2})-(\d{2})$/,(_,m,d)=>`年${+m}月${+d}日`))) throw new AppError('到期时间缺少材料中的明确依据','MODEL_OUTPUT',502);
    return {id:`${material.id}-claim-${index+1}`,text,kind:c.kind,quote,materialId:material.id,validUntil};
  });
  const suggestedEventId=a.suggestedEventId===null?null:str(a.suggestedEventId,'候选事件',1,100);
  const target=suggestedEventId?candidates.find(e=>e.id===suggestedEventId):null;
  if(suggestedEventId&&!target) throw new AppError('模型引用了不存在的候选事件','MODEL_OUTPUT',502);
  if(a.match==='new'&&suggestedEventId) throw new AppError('新事件判断与归并目标矛盾，结论未保存','MODEL_OUTPUT',502);
  if(a.match==='high'&&!target) throw new AppError('归并判断缺少目标事件','MODEL_OUTPUT',502);
  let match=a.match;
  if(target){
    const shares=companies.some(c=>target.companies.some(t=>(c.code&&c.code===t.code)||c.name===t.name));
    const newParty=companies.some(c=>!target.companies.some(t=>(c.code&&c.code===t.code)||c.name===t.name));
    if(!shares||category!==target.category||newParty) match='review';
  }
  return {title,summary,category,companies,claims,occurredAt:dateValue(a.occurredAt),status:a.status,relation:a.relation,suggestedEventId,match,rationale:str(a.rationale,'归并理由',2,800)};
}
function disclosureRange(value:string):[number,number] {
  if(value.length===10){const start=Date.parse(value+'T00:00:00+08:00');return [start,start+86_400_000-1];}
  const instant=Date.parse(value);return [instant,instant];
}
function disclosureOrder(incoming:string|null,previous:string|null|undefined):'before'|'after'|'overlap'|'unknown' {
  if(!incoming||!previous)return 'unknown';
  const [a0,a1]=disclosureRange(incoming);const [b0,b1]=disclosureRange(previous);
  if(a1<b0)return 'before';if(a0>b1)return 'after';return 'overlap';
}
export function applyAnalysis(original:WorkspaceState,materialId:string,analysis:Analysis,run:RunRecord|null,now:string,confirmed=false):WorkspaceState {
  analysis=structuredClone(analysis);
  const state=structuredClone(original);const material=state.materials.find(m=>m.id===materialId);
  if(!material) throw new AppError('找不到材料','NOT_FOUND',404);
  if(material.status==='analyzed') return original;
  if(analysis.match==='new'&&analysis.suggestedEventId)throw new AppError('新事件不能同时指定归并目标');
  let event=analysis.suggestedEventId?state.events.find(e=>e.id===analysis.suggestedEventId):undefined;
  const latest=event?.versions.at(-1);
  const order=disclosureOrder(material.publishedAt,latest?.asOf);
  const changing=latest&&(latest.status!==analysis.status||normalize(latest.summary)!==normalize(analysis.summary));
  const ambiguousTime=latest&&changing&&['unknown','overlap'].includes(order)&&analysis.relation!=='contradicts';
  if(!confirmed&&(analysis.match==='review'||ambiguousTime)) {
    if(ambiguousTime)analysis.rationale+=' 披露时间未知或精度不足，无法确定先后顺序，请人工确认。';
    material.status='review';material.proposedAnalysis=analysis;material.error=null;
    if(run)state.runs.push({...run,status:'review'});state.activeRun=null;return state;
  }
  material.status='analyzed';material.error=null;material.occurredAt=analysis.occurredAt;delete material.proposedAnalysis;
  if(!event){
    event={id:freshId('event'),title:analysis.title,category:analysis.category,companies:analysis.companies,status:analysis.status,summary:analysis.summary,materialIds:[],versions:[],updatedAt:now,needsReview:false};state.events.unshift(event);
  }
  material.eventId=event.id;
  if(!event.materialIds.includes(material.id)) event.materialIds.push(material.id);
  // Disclosure order governs current conclusions, not time of import or a guessed occurrence date.
  const older=latest&&order==='before';
  if(older){ if(run)state.runs.push(run);state.activeRun=null;return state; }
  const conflict=analysis.relation==='contradicts';
  const status=conflict?'uncertain':analysis.status;
  const summary=conflict?`存在尚未解决的证据冲突。${analysis.summary}`:analysis.summary;
  const claims=conflict&&latest?[...latest.claims,...analysis.claims]:analysis.claims;
  const unchanged=latest&&latest.status===status&&normalize(latest.summary)===normalize(summary);
  {
    const asOf=latest?.asOf&&(!material.publishedAt||disclosureRange(latest.asOf)[1]>disclosureRange(material.publishedAt)[1])?latest.asOf:material.publishedAt;
    event.versions.push({id:freshId('version'),number:event.versions.length+1,status,summary,claims,reason:analysis.rationale,relation:analysis.relation,materialId:material.id,updatedAt:now,asOf,provenance:'deepseek'});
    event.status=status;event.summary=summary;event.updatedAt=now;event.needsReview=conflict;
    if(latest&&!unchanged&&(latest.status!==status||['contradicts','corrects','denies','progresses'].includes(analysis.relation)))state.notifications.unshift({id:freshId('notice'),eventId:event.id,title:conflict?'发现证据冲突':'事件结论已更新',body:summary.slice(0,200),createdAt:now,read:false});
  }
  if(run) state.runs.push(run);state.activeRun=null;return state;
}
export function expireClaims(original:WorkspaceState,now:string):WorkspaceState {
  const state=structuredClone(original);
  for(const event of state.events){
    const latest=event.versions.at(-1);if(!latest)continue;
    let changed=false;
    const claims=latest.claims.map(c=>{
      const cutoff=c.validUntil?.length===10?`${c.validUntil}T23:59:59+08:00`:c.validUntil;
      if(cutoff&&!c.expired&&new Date(cutoff).getTime()<new Date(now).getTime()){changed=true;return {...c,expired:true};}return c;
    });
    if(!changed)continue;
    const allExpired=claims.length>0&&claims.every(c=>c.expired);
    const status=allExpired?'expired':event.status;
    const summary=allExpired?'支撑当前结论的时效性陈述均已过期，需补充新证据。':`${event.summary.replace(/^部分时效性陈述已过期，请结合新资料核验。/,'')}`;
    const nextSummary=allExpired?summary:`部分时效性陈述已过期，请结合新资料核验。${summary}`;
    event.versions.push({...latest,id:freshId('version'),number:latest.number+1,claims,status,summary:nextSummary,reason:'刷新时检测到材料明确标注的有效期已结束；历史事实保留。',updatedAt:now,provenance:'expiry'});
    event.status=status;event.summary=nextSummary;event.updatedAt=now;
    state.notifications.unshift({id:freshId('notice'),eventId:event.id,title:'证据时效提醒',body:'有明确有效期的陈述已过期，历史材料仍保留。',createdAt:now,read:false});
  }
  return state;
}
