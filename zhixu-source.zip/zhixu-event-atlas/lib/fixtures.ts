import type { Claim, EventRecord, Material, MaterialInput, Version, WorkspaceState } from './types.ts';
import { materialFingerprint } from './domain.ts';

const CURATED_AT = '2026-10-30T02:00:00Z';
const companies = [{ name: '海光信息', code: '688041' }, { name: '中科曙光', code: '603019' }];
const ids = ['mat-plan', 'mat-preplan', 'mat-terminate', 'mat-dividend'];
const dates = ['2025-05-25', '2025-06-06', '2025-12-09', '2025-12-09'];
const quotes = ['吸收合并意向协议', '本次交易相关各项工作尚未完成', '决定终止本次交易事项', '本次中期分红方案尚需提交股东会审议'];
const summaries = [
  '海光信息与中科曙光于2025年5月25日签署吸收合并意向协议，筹划换股吸收合并及配套融资；海光信息5月26日起停牌，交易仍有不确定性。',
  '双方于2025年6月6日签订换股吸收合并协议，海光董事会同日审议通过预案；预案于6月10日披露，尚需后续审议及审批。',
  '海光信息董事会于2025年12月9日审议通过终止换股吸收合并中科曙光及配套融资；12月10日披露，交易在预案阶段终止。',
  '海光信息董事会于2025年12月9日通过中期现金分红方案，拟每10股派0.90元（含税），尚需股东会审议；属于独立利润分配事项。',
];

export const sampleMaterials: MaterialInput[] = [
  {
    title: '海光信息技术股份有限公司关于筹划重大资产重组的停牌公告',
    text: `【人工核验摘要，非原文全文】\n${summaries[0]}\n【公告原文短引】「${quotes[0]}」`,
    sourceUrl: 'https://star.sse.com.cn/disclosure/listedinfo/announcement/c/new/2025-05-26/688041_20250526_TLXR.pdf',
    sourceKind: 'official', publishedAt: '2025-05-26',
  },
  {
    title: '海光信息技术股份有限公司换股吸收合并曙光信息产业股份有限公司并募集配套资金暨关联交易预案',
    text: `【人工核验摘要，非原文全文】\n${summaries[1]}\n封面列示证券代码688041、603019；签章日期为6月9日，不能与6月6日协议签署或6月10日披露混同。\n【公告原文短引】「${quotes[1]}」`,
    sourceUrl: 'https://static.cninfo.com.cn/finalpage/2025-06-10/1223827019.PDF',
    sourceKind: 'official', publishedAt: '2025-06-10',
  },
  {
    title: '海光信息技术股份有限公司关于终止重大资产重组的公告',
    text: `【人工核验摘要，非原文全文】\n${summaries[2]}\n公告称交易论证历时较长、市场环境变化、实施条件尚不成熟。公告同时提及中期分红，但分红属于独立事件。\n【公告原文短引】「${quotes[2]}」`,
    sourceUrl: 'https://static.cninfo.com.cn/finalpage/2025-12-10/1224863806.PDF',
    sourceKind: 'official', publishedAt: '2025-12-10',
  },
  {
    title: '海光信息技术股份有限公司关于2025年中期现金分红方案的公告',
    text: `【人工核验摘要，非原文全文】\n${summaries[3]}\n该方案与终止重组同公司、同披露日、同次董事会，但不是重组进展；此时尚非分红实施。\n【公告原文短引】「${quotes[3]}」`,
    sourceUrl: 'https://star.sse.com.cn/disclosure/listedinfo/announcement/c/new/2025-12-10/688041_20251210_EF75.pdf',
    sourceKind: 'official', publishedAt: '2025-12-10',
  },
];

const pageHints = [
  'PDF第1页停牌安排、第3页意向协议及落款；公告编号2025-019',
  'PDF第1页封面、第2页声明、第61页协议签署日、第95页签章；披露日经终止公告第2页回溯核验',
  'PDF第1页终止决议、第2页历程及原因、第4页落款；公告编号2025-050',
  'PDF第1页方案、第2页董事会日期及待股东会审议；公告编号2025-052',
];

const materials: Material[] = sampleMaterials.map((input, i) => ({
  ...input, id: ids[i], fingerprint: materialFingerprint(input.text), occurredAt: dates[i],
  ingestedAt: CURATED_AT, fetchedAt: null, origin: 'historical', status: 'analyzed',
  eventId: i === 3 ? 'event-dividend' : 'event-merger', error: null, pageHint: pageHints[i],
}));

function claimsFor(i: number): Claim[] {
  return [{
    id: `claim-${ids[i]}`, text: `人工核验摘要：${summaries[i]}`, kind: 'fact',
    quote: quotes[i], materialId: ids[i], validUntil: null,
  }];
}

const versions: Version[] = [
  {
    id: 'version-plan', number: 1, status: 'planning', summary: summaries[0], claims: claimsFor(0),
    reason: '人工核验：双方、吸收合并方式和意向协议明确，建立历史事件。', relation: 'initial',
    materialId: ids[0], updatedAt: CURATED_AT, asOf: sampleMaterials[0].publishedAt, provenance: 'manual',
  },
  {
    id: 'version-preplan', number: 2, status: 'progress', summary: summaries[1], claims: claimsFor(1),
    reason: '人工核验：同一交易双方及换股吸收合并方案，由筹划进入预案阶段；并非交易完成。', relation: 'progresses',
    materialId: ids[1], updatedAt: CURATED_AT, asOf: sampleMaterials[1].publishedAt, provenance: 'manual',
  },
  {
    id: 'version-terminate', number: 3, status: 'terminated', summary: summaries[2], claims: claimsFor(2),
    reason: '人工核验：终止公告明确回溯相同筹划及预案，当前状态更新为已终止，保留历史版本。', relation: 'progresses',
    materialId: ids[2], updatedAt: CURATED_AT, asOf: sampleMaterials[2].publishedAt, provenance: 'manual',
  },
];

const merger: EventRecord = {
  id: 'event-merger', title: '海光信息拟换股吸收合并中科曙光', category: '并购重组', companies,
  status: 'terminated', summary: summaries[2], materialIds: ids.slice(0, 3), versions,
  updatedAt: CURATED_AT, needsReview: false,
};
const dividend: EventRecord = {
  id: 'event-dividend', title: '海光信息2025年中期现金分红方案', category: '利润分配', companies: [companies[0]],
  status: 'progress', summary: summaries[3], materialIds: [ids[3]],
  versions: [{
    id: 'version-dividend', number: 1, status: 'progress', summary: summaries[3], claims: claimsFor(3),
    reason: '人工核验：独立利润分配方案；同公司同日不构成同一重组事件。', relation: 'initial',
    materialId: ids[3], updatedAt: CURATED_AT, asOf: sampleMaterials[3].publishedAt, provenance: 'manual',
  }], updatedAt: CURATED_AT, needsReview: false,
};

export const demoState: WorkspaceState = {
  schemaVersion: 1, materials, events: [merger, dividend], notifications: [], runs: [],
  usage: { day: '2026-10-30', count: 0 }, activeRun: null,
};

export function baselineState(): WorkspaceState {
  const state = structuredClone(demoState);
  state.materials = state.materials.slice(0, 2);
  state.events = [{ ...state.events[0], status: 'progress', summary: summaries[1], materialIds: ids.slice(0, 2), versions: state.events[0].versions.slice(0, 2) }];
  return state;
}
