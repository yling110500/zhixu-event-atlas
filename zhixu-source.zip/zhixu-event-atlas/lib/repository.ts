import { AppError, emptyState } from './domain.ts';
import type { WorkspaceState } from './types.ts';

/** The small D1 surface needed here also permits SQLite integration tests. */
export interface WorkspaceDatabase {
  prepare(sql: string): { bind(...values: unknown[]): { first(): Promise<unknown>; run(): Promise<{ meta?: { changes?: number } }> } };
}
export interface WorkspaceSnapshot { state: WorkspaceState; revision: number | null; }
export class WorkspaceRepository {
  private db: WorkspaceDatabase;
  constructor(db: WorkspaceDatabase) { this.db=db; }
  async read(owner: string): Promise<WorkspaceSnapshot> {
    const row=await this.db.prepare('SELECT data, revision FROM workspaces WHERE owner = ?').bind(owner).first() as {data:string;revision:number}|null;
    return row?{state:JSON.parse(row.data) as WorkspaceState,revision:row.revision}:{state:emptyState(),revision:null};
  }
  async compareAndSwap(owner:string,revision:number|null,state:WorkspaceState):Promise<boolean> {
    const data=JSON.stringify(state);
    const result=revision===null
      ?await this.db.prepare('INSERT INTO workspaces (owner, data, revision) VALUES (?, ?, 1) ON CONFLICT(owner) DO NOTHING').bind(owner,data).run()
      :await this.db.prepare('UPDATE workspaces SET data = ?, revision = revision + 1 WHERE owner = ? AND revision = ?').bind(data,owner,revision).run();
    return result.meta?.changes===1;
  }
  async update(owner:string,transition:(state:WorkspaceState)=>WorkspaceState):Promise<WorkspaceState> {
    for(let attempt=0;attempt<12;attempt++) {
      const current=await this.read(owner);const next=transition(current.state);
      if(next===current.state)return current.state;
      if(await this.compareAndSwap(owner,current.revision,next))return next;
    }
    throw new AppError('研究空间正在更新，请重试','WRITE_CONFLICT',409);
  }
}
