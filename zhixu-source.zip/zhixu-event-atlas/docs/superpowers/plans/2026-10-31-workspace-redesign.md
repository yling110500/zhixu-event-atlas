# Workspace redesign implementation plan

> **For agentic workers:** use executing-plans to implement the bounded tasks below. The user has explicitly requested these changes; proceed with implementation and publication.

**Goal:** Make the default page an immediately usable material composer, with accessible history navigation and a restrained financial research design.

**Architecture:** Retain existing API, anonymous identity, persistent workspace and evidence/version model. Change navigation and presentation only. Local page selection distinguishes a new research composer from an explicitly selected personal or sample event; never invent chat conversations or mix sample data into personal records.

**Tech Stack:** Existing React/Vinext, CSS, Cloudflare D1 and DeepSeek.

**Spec:** User request 2026-10-31: fix obstructed sidebar; rigorous new visual style; less copy; explanatory hints on hover; default event desk supports uploading; history opens from sidebar like ChatGPT conversations.

## Global constraints

- Preserve existing public Site identity, deployment and data; no data deletion or reset.
- Source is existing isolated checkout work/event-atlas. Do not add dependencies or change secrets.
- Neutral white/slate palette, restrained navy accent, readable 13–15 px secondary text; remove slogans and decorative English.
- Sidebar must have a real independently scrollable history area with min-height:0 and small non-overlapping footer. Mobile navigation remains accessible.
- Default research composer visible without an extra modal or mode switch, even for returning users.
- Side list groups personal history and clearly marked sample cases; selecting a row opens evidence timeline and versions. New research returns to composer without deleting data.
- Tooltips support hover, keyboard focus and touch/click. Required fields, errors, progress, source/provenance labels and current/historical status remain visible.

## Review focus

- Returning workspace with many events at short height: list scrolls; footer never overlays rows.
- Import/analyze failure or review required: pending material, original input and retry controls remain reachable.
- Sample case vs personal history: row selection chooses correct dataset, never creates personal data silently.
- Refresh after analysis: default composer appears while prior events remain available in sidebar.
- Narrow phone screen: composer fields, drawer, dialogs and navigation stay within viewport.

## Tasks

1. [ ] UI redesign in app/page.tsx and app/globals.css (optional small components). Preserve evidence, calls, versions, notices, quota and source links; reuse shared composer logic for page and add-material modal. Validate via typecheck and real browser interactions.
2. [ ] Produce outputs/验收资料 with four JSON samples based on existing verified fixtures and a concise step-by-step acceptance checklist. Validate all files with the actual material validator; distinguish expected semantic invariants from variable AI wording.
3. [ ] Run existing 48 tests, typecheck, browser QA at desktop and phone/short viewport. Inspect source and independent review. Build, publish to same public URL, refresh source archives and GitHub if feasible; report actual verification.
