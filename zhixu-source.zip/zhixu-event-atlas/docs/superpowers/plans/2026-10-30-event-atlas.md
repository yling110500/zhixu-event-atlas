# Event Atlas Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans. Steps use checkbox syntax for tracking.

**Goal:** Deliver a Chinese evidence-first event research application with genuine DeepSeek analysis and a clearly labeled historical replay.
**Architecture:** React client calls same-origin server routes. Pure domain transitions validate citations and preserve immutable versions; a D1 workspace row per authenticated user uses revision-checked writes. Historical fixtures stay separate from user-created research.
**Tech Stack:** Vinext, React, TypeScript, Cloudflare D1, Node built-in tests, DeepSeek HTTP API. Use bundled Node and pnpm because host PATH has neither Node nor npm.
**Spec:** docs/superpowers/specs/2026-10-30-event-atlas-design.md

## Global Constraints

- 24-hour delivery; no iFinD dependency; user has a key and configures it locally.
- Only genuine model calls may be labeled DeepSeek; historical curated snapshots are labeled 人工核验历史案例.
- Missing dates remain null; fetch time is null for manually imported materials.
- References must match preserved supplied text; no hidden reasoning is evidence.
- Never expose a key; no investment recommendations; no arbitrary URL fetching or execution from documents.
- Account-scoped persistence, same-origin mutations, bounded input, 20 analyses/day, one active analysis per workspace.

## Review Focus

1. Unrelated same-company same-day documents must not silently merge (domain tests).
2. Late older disclosure must not undo a newer event status (domain tests).
3. Timeout/malformed output/invalid quotes must preserve pending material and existing versions (provider/service tests).
4. Concurrent saves must not overwrite versions or create duplicate notices (repository CAS integration tests).
5. Missing key, anonymous writes and document HTML/instructions must not become credential leakage or executable content (API/browser checks).

## Task 1 Domain and evidence validation

Files: lib/types.ts, lib/domain.ts, tests/domain.test.ts.
Interfaces: validateMaterial(input), validateAnalysis(raw, material, candidates), applyAnalysis(state, materialId, analysis, run, now), expireClaims(state,now), materialFingerprint(text). Types shared with client in lib/types.ts.
- [ ] Write failing tests for quote mismatch, future/invalid dates, idempotency, mismatch grouping, out-of-order materials, immutable versions, contradiction and expiry.
- [ ] Run node --experimental-strip-types --test tests/domain.test.ts; expect failures before implementation.
- [ ] Implement the pure domain functions, run tests to green, commit.

## Task 2 Model and persistent service

Files: lib/provider.ts, lib/repository.ts, lib/service.ts, db/schema.ts, drizzle migration, app/api/[...path]/route.ts, tests/provider.test.ts, tests/repository.test.ts.
Interfaces: Provider analyzes one Material and candidate EventRecords; WorkspaceRepository.read(owner) and compareAndSwap(owner,revision,state); service routes return {state,configured,model,authenticated} for GET and JSON errors for failures.
- [ ] Write failing provider tests for valid output, missing key, HTTP errors, empty/truncated output, bogus quotes and request abort.
- [ ] Add atomic SQL workspace storage and a real SQLite test adapter to test CAS conflicts and owner isolation.
- [ ] Implement routes: GET workspace; POST materials, analyze, resolve, expire, notifications/read, seed. Validate same origin and authenticated user; check bounded body and 20/day limit before any paid call.
- [ ] Run tests and typecheck; generate schema-only migration; commit.

## Task 3 Historical evidence pack

Files: lib/fixtures.ts, docs/source-research.md, docs/demo-script.md.
Interfaces: export demoState: WorkspaceState; export sampleMaterials: MaterialInput[]; export baselineState(): WorkspaceState.
- [ ] Use four already verified official sources. Include only short exact excerpts verified from original; label summaries as paraphrases and source type as official.
- [ ] Construct 3 immutable manual versions for the merger and one separate dividend event; baseline contains first two merger materials.
- [ ] Test source IDs and quote matching, chronological snapshots and separate event identity; commit.

## Task 4 Interactive research workbench

Files: app/page.tsx, app/globals.css, app/layout.tsx, public/favicon.svg.
Interfaces: consumes shared types and GET /api/workspace; uses POST routes above. Client never imports provider/secrets.
- [ ] Build restrained ink/ivory/teal desktop workspace with event list, searchable filters, narrative status, timeline, evidence drawer, versions, reminders, material form and historical replay.
- [ ] Historical mode is read-only and explicit; research mode persists through API. Import error/retry, no-key state and loading states remain actionable. Exact source quotations are escaped React text.
- [ ] Verify browser flows and narrow viewport after backend integration; commit.

## Task 5 Acceptance and review

Files: tests/*, docs/validation.md, docs/ai-record.md, README.md, .env.example.
- [ ] Run all tests, typecheck and build; apply local migration and verify persistence via HTTP.
- [ ] After user configures key, run genuine analysis with source-linked material. Record outcome honestly; absent key remains a stated blocker only for this check.
- [ ] Independent review of evidence handling, state concurrency, auth, provenance and UI; fix material issues with regression tests.

## Task 6 Publication and handoff

Files: outputs archive and video outside checkout.
- [ ] Publish private Site through supported source helper; verify actual deployment result.
- [ ] Create portable source ZIP with no keys/runtime data and README/test/AI records. Capture a 60–180 second demonstration or clearly report any recording limit.
- [ ] Obtain final user choice for reviewer access/public sharing only once there is a concrete working result. Private URL alone is not external reviewer access verification.

## Execution record

User approved implementation on 2026-10-30. Proceed without another plan approval: authorization covers the agreed deliverable. Root owns core/backend and integration; bounded independent fixture/UI work may be delegated. Local fresh repository is isolated at work/event-atlas, branch build/event-atlas; no existing repo needs a worktree. Package manager adapted to bundled pnpm; no user files replaced.
